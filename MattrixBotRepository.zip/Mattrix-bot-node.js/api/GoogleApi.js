const { Google } = require("../config.js");
const { google } = require("googleapis");
const customSearch = google.customsearch("v1");

const searchImage = async (query, n) => {
  const response = await customSearch.cse.list({
    auth: Google.apiKey,
    cx: Google.searchEngineId,
    q: query,
    num: n,
    searchType: "image",
  });
  if (!response.data.items) {
    return false;
  }
  const img_urls = response.data.items.map((item) => {
    let obj = {
      th: item.image.thumbnailLink,
      lk: item.link,
    };
    return obj;
  });

  return img_urls;
};
module.exports = {
  searchImage,
};
