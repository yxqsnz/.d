const imgur = require("imgur");
async function search(query) {
  var optionalParams = { sort: "top", dateRange: "week", page: 1 };
  return imgur
    .search(query)
    .then(function (json) {
      let sl = Math.round(Math.random() * json.data.length);

      return json.data[sl];
    })
    .catch(function (err) {
      console.error(err);
    });
}
async function GetImageData(imageID) {
  return imgur
    .getInfo(imageID)
    .then(function (json) {
      return json;
    })
    .catch(function (err) {
      console.error(err.message);
    });
}
module.exports = {
  search,
  GetImageData,
};
