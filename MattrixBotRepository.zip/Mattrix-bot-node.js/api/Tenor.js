const Tenor = require("tenorjs");

const TenorClient = Tenor.client({
  Key: "TW41BLEAIO0R", // https://tenor.com/developer/keyregistration
  Filter: "off", // "off", "low", "medium", "high", not case sensitive
  Locale: "en_US", // Your locale here, case-sensitivity depends on input
  MediaFilter: "minimal", // either minimal or basic, not case sensitive
  DateFormat: "D/MM/YYYY - H:mm:ss A", // Change this accordingly
});
module.exports = {
  TenorClient,
};
