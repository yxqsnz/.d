const nekosAPI = require('nekos.life')

module.exports = NekosClient = new nekosAPI
