
async function Search(query){
    const r34 = require('api-rule34-xxx')

const rs = await r34.searchByText(query);
if(rs.length <= 0){
    return false;
}
let v = Math.round(Math.random() * rs.length) -1
if(v<=0){
    v = 0;
}
if(v>rs.length){
    v = rs.length -1;
}
const r = rs[v]

const Id = r.id;
const thumbnail = r.thumbnail;
const Post = await r34.getPost(Id)
const Img = Post.pages[0].imgURL;
const PostID = Post.id;
const PostArtists = Post.artists;
const PostCopyrights = Post.copyrights;
const PostTags = Post.tags;
const PostChars = Post.characters;
const R = {
    id:Id,
    thumbnail:thumbnail,
    img:Img,
    postId: PostID,
    postArtists:PostArtists,
    postCopyrights:PostCopyrights,
    postTags:PostTags,
    postChars:PostChars,
}   
return R;
}
module.exports ={
    Search
}