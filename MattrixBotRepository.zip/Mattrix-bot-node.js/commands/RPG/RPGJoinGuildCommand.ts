import * as discord from 'discord.js'
import * as database from '../../Scripts/Utils/database'
import * as emoji from '../../Scripts/Utils/Bot_Emojis'
// import * as rpgds from '../../Config/defaultRPGacc.json'
module.exports = {
    
    name : "rpg-joinguild",
    aliases : ['rpg-jguild', 'r-jguild'],
    /**
     * @param {discord.Message} msg
     * @param {discord.Client} client
     * @param {String[]} args
     */
    run : async(client:discord.Client, msg:discord.Message, args:String[]) => {
        
        const embed = new discord.MessageEmbed
        embed.setTitle(`${emoji.loading(client)} Carregando`)
        const message = await msg.channel.send(embed)
        if(!args[0]){
            embed.setTitle(`Você não colocou o ID Da Guilda que quer entrar`)
            return message.edit(embed)
        }
        const RPGDB = await database.Client.db("RPG");
        const users = await RPGDB.collection("Users");
        const user = await users.findOne({ user_id: msg.author.id });
        if(!user){
            embed.setTitle(` você não tem uma conta no RPG`)
            return message.edit(embed)
        }
        const GID = args[0]
        const guilds = await RPGDB.collection("Guilds");
        const guild = await guilds.findOne({ Guild_id: GID })
        if(!guild){
            embed.setTitle(`Você não colocou uma Guilda Validá!`)
            return message.edit(embed)
        }
        if(user.In_Guild){
            embed.setTitle(`Você já está em uma guilda!`)
            return message.edit(embed)
        }
        let hasBanned
        for(let i = 0; i < guild.banned.length; i++){
            if(msg.author.id == guild.banned[i]){
                hasBanned = true
                break
            }
        }
        if(hasBanned){
            embed.setTitle(`Você está banido desta guilda!`)
            return message.edit(embed)
        }


        await guilds.updateOne(
            { Guild_id: GID},
            {
                $set: {Members_count: guild.Members_count +1},
                $push: {Members: msg.author.id}
            }
        )
        const GuildName = guild.Guild_Name
        await users.updateOne(
            {user_id: msg.author.id},
            {
                $set: {Guild: GuildName, In_Guild: true, Guild_Id: guild.Guild_id}
            }
        )
        embed.setTitle('Você entrou na guilda ' + guild.Guild_Name + " com sucesso!")
        message.edit(embed)

    }
}