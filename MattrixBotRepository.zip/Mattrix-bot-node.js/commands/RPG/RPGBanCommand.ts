import * as discord from 'discord.js'
import * as database from '../../Scripts/Utils/database'
import * as emoji from '../../Scripts/Utils/Bot_emojis_ts'
    module.exports = {
    name : 'rpg-guildban',
    aliases : ['r-gban'],
    run : async(client:discord.Client, message: discord.Message, args:string[],text) => {
        const embed = new discord.MessageEmbed
        const botloading = await emoji.FindEmojiByName(client, "bot_loading")
        const error = await emoji.FindEmojiByName(client, 'bot_error')
        embed.setTitle(`${botloading} - ...`)
        const m = await message.channel.send(embed)
        if(!args[0]){
            embed.setTitle(`${error} - ${text.getGuildLocale(message.guild.id,"RPGBanMissingID")}`)
            return m.edit(embed)
        }
        const RPGDB = await database.Client.db("RPG");
        const users = await RPGDB.collection("Users");
        const user = await users.findOne({ user_id: message.author.id });
        const okay = await emoji.FindEmojiByName(client, 'bot_ok')
        if(!user){
            embed.setTitle(`${error} - ${text.getGuildLocale(message.guild.id,"RPGDontHaveAccount")}`)
            return m.edit(embed)
        }
        
        
        if(!user.In_Guild){
            embed.setTitle(`${error} - ${text.getGuildLocale(message.guild.id, "RPGNotInGuild")}`)
            return m.edit(embed)
        }
        const guilds = await RPGDB.collection("Guilds");
        const guild = await guilds.findOne({Guild_id: user.Guild_id})
        let UserExist = false
        for(let i = 0; i < guild.Members.length; i++){
            if(args[0] == guild.Members[i]){
                UserExist = true
                break
            }
        }
    
        if(guild.Guild_owner != message.author.id){
            embed.setTitle(`${error} - ${text.getGuildLocale(message.guild.id, "RPGNotGuildOwner")}`)
            return m.edit(embed)
        }
        if(!UserExist){
            embed.setTitle(`${error} - ${text.getGuildLocale(message.guild.id, "RPGIDAccountNotFound")}`)
            return m.edit(embed)  
        }
        await guilds.updateOne(
            {Guild_id: guild.Guild_id},
            {
                $pull: {Members: { $in: [args[0]]}},
                $set: {Members_count: guild.Members_count -1},
                $push: {banned: args[0]}
            },
            
        )
        const usertKick = await users.findOne({user_id: args[0]})
        if(!usertKick){
            embed.setTitle(`${okay} - ${text.getGuildLocale(message.guild.id,"RPGBanSuccess")}`)
            return m.edit(embed)
        }
        await users.updateOne(
            {user_id: args[0]},
            {
                $set: {In_Guild: false, Guild: "Não está numa Guilda/ NOT IN GUILD", Guild_Id: 0}
            }
        )
        embed.setTitle(`${okay} - ${text.getGuildLocale(message.guild.id,"RPGBanSuccess")}`)
        m.edit(embed)


    }

}