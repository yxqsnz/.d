import * as discord from 'discord.js'
import * as database from '../../Scripts/Utils/database'
import * as emoji from '../../Scripts/Utils/Bot_emojis_ts'
    module.exports = {
    name : 'rpg-guildkick',
    aliases : ['r-gkick', 'rpg-guildkick'],
    run : async(client:discord.Client, msg: discord.Message, args:string[]) => {
        const embed = new discord.MessageEmbed
        const botloading = await emoji.FindEmojiByName(client, "bot_loading")
        const error = await emoji.FindEmojiByName(client, 'bot_error')
        embed.setTitle(`${botloading} Carregando`)
        const m = await msg.channel.send(embed)
        if(!args[0]){
            embed.setTitle(`${error} Você não colocou o ID de quem kickar!`)
            return m.edit(embed)
        }
        const RPGDB = await database.Client.db("RPG");
        const users = await RPGDB.collection("Users");
        const user = await users.findOne({ user_id: msg.author.id });
        const okay = await emoji.FindEmojiByName(client, 'bot_ok')
        if(!user){
            embed.setTitle(`${error} Você não tem uma conta!`)
            return m.edit(embed)
        }
        
        console.log(user.In_Guild)
        if(!user.In_Guild){
            embed.setTitle(`${error} Você não está em uma guilda!`)
            return m.edit(embed)
        }
        const guilds = await RPGDB.collection("Guilds");
        const guild = await guilds.findOne({Guild_id: user.Guild_id})
        let UserExist = false
        for(let i = 0; i < guild.Members.length; i++){
            if(args[0] == guild.Members[i]){
                UserExist = true
                break
            }
        }
    
        if(guild.Guild_owner != msg.author.id){
            embed.setTitle(`${error} Você não é o dono da guilda!`)
            return m.edit(embed)
        }
        if(!UserExist){
            embed.setTitle(`${error} eu não achei o ID deste usuario na guilda!`)
            return m.edit(embed)  
        }
        await guilds.updateOne(
            {Guild_id: guild.Guild_id},
            {
                $pull: {Members: { $in: [args[0]]}},
                $set: {Members_count: guild.Members_count -1}
            },
            
        )
        const usertKick = await users.findOne({user_id: args[0]})
        if(!usertKick){
            embed.setTitle(`${okay} usuario Kickado com sucesso!`)
            return m.edit(embed)
        }
        await users.updateOne(
            {user_id: args[0]},
            {
                $set: {In_Guild: false, Guild: "Não está numa Guilda", Guild_Id: 0}
            }
        )
        embed.setTitle(`${okay} usuario Kickado com sucesso!`)
        m.edit(embed)

    }

}