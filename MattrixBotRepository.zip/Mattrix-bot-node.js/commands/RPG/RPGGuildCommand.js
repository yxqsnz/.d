const discord = require("discord.js");

const emoji = require("../../Scripts/Utils/Bot_Emojis");
const database = require("../../Scripts/Utils/database");
module.exports = {
    name : "rpg-guildinfo",
    aliases : ['r-ginfo'],
    usage : '(opcional) => <guildId>',
    /**
     * @param {discord.Client} client
     * @param {discord.Message} msg
     * @param {String[]} args
     */
    run : async(client, msg, args) => {
        const embed = new discord.MessageEmbed()
        embed.setTitle(`${emoji.loading(client)} Carregando`)
        const message = await msg.channel.send(embed)
        const RPGDB = await database.Client.db("RPG");
        const users = await RPGDB.collection("Users");
        const user = await users.findOne({ user_id: message.author.id });
        const guilds = await RPGDB.collection("Guilds");
        if(args[0]){
            
            const GFind = await guilds.findOne({Guild_id: args[0]})
            
            if(!GFind){
                embed.setTitle(`${emoji.error(client)} ERRO`)
                embed.setDescription(`Você não colocou um Guild-Id Válido.`)
                return message.edit(embed)
            }
            
            let GuildMembers = `MEMBROS: \n`
            for(let i = 0; i < GFind.Members.length; i++){
                GuildMembers += `${client.users.cache.get(GFind.Members[i]).username}\n`
                if(GuildMembers.length > 1700){
                    break
                }
            }
            let guildOwner = client.users.cache.get(GFind.Guild_owner).username
            embed.addFields(
                {
                    name: `${GFind.Guild_Name}`, value: `**
                    ID: ${GFind.Guild_id}
                    Quantidade de Membros: ${GFind.Members_count}
                    LEVEL: ${GFind.Guild_Level}
                    LIDER: ${guildOwner}
                    WINS: ${GFind.guild_Wins}
                    ${GuildMembers}
                    **`
                }
            )
            message.edit(embed)
            return
        }
        



        const ES = ['➡️', '⬅️']
        var CurrentlyPag = 0
            async function ShowGuilds(start){
                
                const ArrGuild = await guilds.find().toArray()
                let max = start + 5
                if(max > ArrGuild.length) max = ArrGuild.length
                embed.fields = []
                
                for(let i = start; i < max; i++){

                    if(!ArrGuild[i]) max = i
                    if(!ArrGuild[i])break
                    let guildOwner = client.users.cache.get(ArrGuild[i].Guild_owner).username
                    await embed.addFields(
                        {
                            
                            name: `${ArrGuild[i].Guild_Name}`, value: `**
                                ID: ${ArrGuild[i].Guild_id}
                                Quantidade de Membros: ${ArrGuild[i].Members_count}
                                LEVEL: ${ArrGuild[i].Guild_Level}
                                LIDER: ${guildOwner}
                                WINS: ${ArrGuild[i].guild_Wins}
                            **`
                        }
                    )
                    
                    
                }
                embed.setTitle(`${emoji.ok(client)} Guildas ${max} / ${ArrGuild.length}`)
                message.edit(embed)
                
            }
            await ShowGuilds(CurrentlyPag)
            message.react(ES[1])
            message.react(ES[0])
            const filter = (reaction, user) => {
                return reaction.emoji.name === ES[0] || reaction.emoji.name === ES[1] 
            };
            const coletor = message.createReactionCollector(filter, {time: 1000 * 60 * 2})
            coletor.on('collect', (reaction, user) => {
                if(user.id == msg.author.id){
                    switch(reaction.emoji.name){
                        case ES[0]:
                            CurrentlyPag += 5
                            ShowGuilds(CurrentlyPag)
                            break
                        case ES[1]:
                                CurrentlyPag -= 5
                                if(CurrentlyPag < 0){
                                    CurrentlyPag = 0
                                }
                                ShowGuilds(CurrentlyPag)
                            break
                    }

                }

            })
        
        
    }
}