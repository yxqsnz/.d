const discord = require("discord.js");
const rpgds = require("../../Config/defaultRPGacc.json");
const emoji = require("../../Scripts/Utils/Bot_Emojis");
const database = require("../../Scripts/Utils/database");
module.exports = {
  name: "rpg-createprofile",
  description: "Criar seu perfil.",
  category: "RPG",

  /**
   *
   * @param {discord.Client} client
   * @param {discord.Message} message
   * @param {String[]} args
   */
  run: async (client, message, args) => {
    const embed = new discord.MessageEmbed();
    embed.setColor("2f3136");
    embed.setTitle(`${emoji.loading(client)} | Criando uma conta...`);
    const msg = message.channel.send(embed);
    const RPGDB = await database.Client.db("RPG");
    const users = await RPGDB.collection("Users");
    const user_acc = await users.findOne({ user_id: message.author.id });
    if (user_acc) {
      embed.setTitle(`${emoji.error(client)} | Você já tem uma conta!`);
      (await msg).edit(embed);
      return;
    }

    const User = {
      user_id: message.author.id,
      Guild: "Não está numa Guilda",
      Guild_Id: 0,
      In_Guild: false,
      Guild_id: -1,
      Life: rpgds.Life,
      Mana: rpgds.Mana,
      Level: rpgds.Level,
      Magic_Lv: rpgds.Magic_Lv,
      Magic_Damage: rpgds.Magic_Damage,
      Skill_Points: rpgds.Skill_Points,
      physical_damage: rpgds.physical_damage,
      Strength_Lv: rpgds.Strength_Lv,
      Skills: rpgds.Skills,
      Defence_Lv: rpgds.Defence_Lv,
      Points: rpgds.Points,
      Kills: rpgds.kills,
      deaths: rpgds.deaths,
      Gold: 100,
    };
    users.insertOne(User);
    embed.setTitle(`${emoji.ok(client)}| Sua conta foi criada!`);
    (await msg).edit(embed);
  },
};
