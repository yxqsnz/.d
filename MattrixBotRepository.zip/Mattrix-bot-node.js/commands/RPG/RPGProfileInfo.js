const discord = require("discord.js");

const emoji = require("../../Scripts/Utils/Bot_Emojis");
const database = require("../../Scripts/Utils/database");
module.exports = {
  name: "rpg-profileinfo",
  description: "Ver seu perfil.",
  category: "RPG",

  /**
   *
   * @param {discord.Client} client
   * @param {discord.Message} message
   * @param {String[]} args
   */
  run: async (client, message, args) => {
    const embed = new discord.MessageEmbed();
    embed.setColor("2f3136");
    embed.setTitle(`${emoji.loading(client)} | Carregando sua conta...`);
    const msg = message.channel.send(embed);
    const RPGDB = await database.Client.db("RPG");
    const users = await RPGDB.collection("Users");

    const user_acc = await users.findOne({ user_id: message.author.id });
    if (!user_acc) {
      embed.setTitle(`${emoji.error(client)} | Você não tem uma conta!`);
      (await msg).edit(embed);
      return;
    }
    
    
    embed.setTitle("Sua conta");
    embed.setThumbnail(message.author.displayAvatarURL());
    embed.addField("Guilda", user_acc.Guild, false);
    embed.addField("Level", user_acc.Level, false);
    embed.addField("Vida", user_acc.Life, false);
    embed.addField("Mana", user_acc.Mana, false);
    embed.addField("Nível de Magica", user_acc.Magic_Lv, false);
    embed.addField("Pontos de Skill", user_acc.Skill_Points, false);
    embed.addField("Pontos", user_acc.Points, false);
    embed.addField("Kills", user_acc.Kills, false);
    embed.addField("Mortes", user_acc.deaths, false);
    embed.addField("Nível de defesa", user_acc.Defence_Lv, false);
    embed.addField("Nível de força", user_acc.Strength_Lv, false);
    embed.addField("Dano Físico", user_acc.physical_damage, false);
    embed.addField("Dano Magico", user_acc.Magic_Damage, false);
    embed.addField("Ouro", user_acc.Gold, false);
    (await msg).edit(embed);
  },
};
