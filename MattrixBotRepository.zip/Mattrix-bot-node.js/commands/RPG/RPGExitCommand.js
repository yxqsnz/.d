const discord = require("discord.js");
const emoji = require("../../Scripts/Utils/Bot_Emojis");
const database = require("../../Scripts/Utils/database");
module.exports = {
  name: "rpg-exitguild",
  aliases: ["r-eguild", "r-qguild", "r-quitguild"],
  /**
   *
   * @param {discord.Client} client
   * @param {discord.Message} msg
   * @param {String[]} args
   */
  run: async (client, msg, args) => {
    const embed = new discord.MessageEmbed();
    embed.setTitle(`${emoji.loading(client)} Carregando`);
    const message = await msg.channel.send(embed);
    const RPGDB = await database.Client.db("RPG");
    const users = await RPGDB.collection("Users");

    const user = await users.findOne({ user_id: msg.author.id });
    const guild_name = user.Guild;
    
    if (!user) {
      embed.setTitle(`${emoji.error(client)} ERRO`);
      embed.setDescription(`Você não tem uma conta!`);
      return message.edit(embed);
    }
    if (!user.In_Guild) {
      embed.setTitle(`${emoji.error(client)} ERRO`);
      embed.setDescription(`Você não está em uma guilda!`);
      return message.edit(embed);
    }
    const guilds = await RPGDB.collection("Guilds");
    const UserGuild = await guilds.findOne({ Guild_id: user.Guild_id });
    if (!UserGuild) {
      message.reply("Desculpe ocorreu um erro ao sair da guilda. ");
      return;
    }
    await guilds.updateOne(
      { Guild_id: user.Guild_id },
      {
        $set: { Members_count: UserGuild.Members_count - 1 },
      }
    );

    if (UserGuild.Guild_owner == msg.author.id) {
      await guilds.findOneAndDelete({ Guild_id: user.Guild_id });
      for (let i = 0; i < UserGuild.Members.length; i++) {
        let id = UserGuild.Members[i];
        await users.updateOne(
          { user_id: id },
          {
            $set: {
              In_Guild: false,
              Guild: "Não está numa Guilda",
              Guild_id: -1,
            },
          }
        );
      }
      embed.setTitle(`${emoji.ok(client)} Guilda apagada com sucesso`);
      embed.description = null;
      message.edit(embed);
      
    }
    await users.updateOne(
      { user_id: msg.author.id },
      {
        $set: { In_Guild: false, Guild: "Não está numa Guilda", Guild_id: -1 },
      }
    );
    embed.setTitle(
      `${emoji.ok(client)} Você saiu da guilda "${guild_name}" com sucesso!`
    );
    embed.description = null;
    return message.edit(embed);
  },
};
