const discord = require("discord.js");

const emoji = require("../../Scripts/Utils/Bot_Emojis");
const database = require("../../Scripts/Utils/database");
module.exports = {
  name: "rpg-createguild",
  description: "Criar uma Guilda",
  aliases: ["rpg-cguild", "rpg-criarguilda"],
  usage: "<Nome da guida>",
  /**
   *
   * @param {discord.Client} client
   * @param {discord.Message} message
   * @param {String[]} args
   */
  run: async (client, message, args) => {
    if (!args.length) {
      message.reply(
        "Desculpe,está faltando um argumento `nome da guilda` que é obrigatório"
      );
      return;
    }
    args = args.join(" ");
    if (args.length >= 40) {
      message.reply("O nome da guilda está muito grande!");
      return;
    }
    const embed = new discord.MessageEmbed();
    embed.setColor("2f3136");
    embed.setTitle(`${emoji.loading(client)} -> Criando Guilda ${args}...`);

    const msg = await message.channel.send(embed);
    const RPGDB = await database.Client.db("RPG");
    const users = await RPGDB.collection("Users");
    const user = await users.findOne({ user_id: message.author.id });
    const guilds = await RPGDB.collection("Guilds");
    let guildid = Math.round(Math.random() * 9999999999999999);
    const g = await guilds.findOne({ Guild_id: guildid });
    const go = await guilds.findOne({ Guild_Name: args });
    const gon = await guilds.findOne({ Guild_owner: msg.author.id });
    if (gon) {
      embed.setTitle("Desculpe");
      embed.setDescription("Você já tem uma guilda!");
    }
    if (user.In_Guild) {
      embed.setTitle("Desculpe");
      embed.setDescription("você já está numa guilda!");
      await msg.edit(embed);
      return;
    }
    if (!user) {
      embed.setTitle("Desculpe");
      embed.setDescription("Você não tem uma conta!");
      await msg.edit(embed);
      return;
    }

    if (go) {
      embed.setTitle("Desculpe");
      embed.setDescription("Já existe uma guilda com esse nome!");
      await msg.edit(embed);
      return;
    }
    if (g) {
      guildid = Math.round(Math.random() * 9999999999999999);
    }

    const Guild = {
      Guild_Name: args,
      Guild_id: guildid.toString(),
      Members_count: 1,
      Members: [message.author.id],
      Guild_Level: "1",
      Guild_owner: message.author.id,
      guild_Wins: 0,
      banned: [],
    };
    guilds.insertOne(Guild);
    await users.updateOne(
      {
        user_id: message.author.id,
      },
      {

        $set: { Guild: args, In_Guild: true },
        $set: { Guild_Id: Guild.Guild_id},

        $set: { Guild: args, In_Guild: true, Guild_id: guildid.toString() }

      }
    );
    embed.setColor(message.member.displayHexColor);
    embed.setTitle("Guilda Criada!");
    embed.setDescription(`A guilda ${args} foi criada!`);
    embed.setFooter(message.author.tag, message.author.displayAvatarURL());
    msg.edit(embed);
  },
};
