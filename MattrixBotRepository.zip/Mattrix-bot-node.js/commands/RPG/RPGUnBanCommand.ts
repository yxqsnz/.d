import * as discord from 'discord.js'
import * as database from '../../Scripts/Utils/database'
import * as emoji from '../../Scripts/Utils/Bot_emojis_ts'
    module.exports = {
    name : 'rpg-guildunban',
    aliases : ['r-gunban'],
    run : async(client:discord.Client, msg: discord.Message, args:string[]) => {
        const embed = new discord.MessageEmbed
        const botloading = await emoji.FindEmojiByName(client, "bot_loading")
        const error = await emoji.FindEmojiByName(client, 'bot_error')
        embed.setTitle(`${botloading} Carregando`)
        const m = await msg.channel.send(embed)
        if(!args[0]){
            embed.setTitle(`${error} Você não colocou o ID de quem desbanir!`)
            return m.edit(embed)
        }
        const RPGDB = await database.Client.db("RPG");
        const users = await RPGDB.collection("Users");
        const user = await users.findOne({ user_id: msg.author.id });
        const okay = await emoji.FindEmojiByName(client, 'bot_ok')
        if(!user){
            embed.setTitle(`${error} Você não tem uma conta!`)
            return m.edit(embed)
        }
        
        console.log(user.In_Guild)
        if(!user.In_Guild){
            embed.setTitle(`${error} Você não está em uma guilda!`)
            return m.edit(embed)
        }
        const guilds = await RPGDB.collection("Guilds");
        const guild = await guilds.findOne({Guild_id: user.Guild_id})
        let UserExist = false
        for(let i = 0; i < guild.banned.length; i++){
            if(args[0] == guild.banned[i]){
                UserExist = true
                break
            }
        }
    
        if(guild.Guild_owner != msg.author.id){
            embed.setTitle(`${error} Você não é o dono da guilda!`)
            return m.edit(embed)
        }
        if(!UserExist){
            embed.setTitle(`${error} eu não achei o ID deste usuario na lista de banimentos da guilda!`)
            return m.edit(embed)  
        }
        await guilds.updateOne(
            {Guild_id: guild.Guild_id},
            {
                $pull: {banned: {$in: [args[0]]}}
                
            },
            
        )
        const usertKick = await users.findOne({user_id: args[0]})
        if(!usertKick){
            embed.setTitle(`${okay} usuario desbanido com sucesso!`)
            return m.edit(embed)
        }
        
        embed.setTitle(`${okay} usuario desbanido com sucesso!`)
        m.edit(embed)

    }

}
