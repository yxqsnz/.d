const emoji = require("../../Scripts/Utils/Bot_Emojis.js");
const imgur = require("../../api/Imgur");
const discord = require("discord.js");
module.exports = {
  name: "searchforavatar",
  aliases: ["sfv"],
  description: "Procura um avatar no IMGUR",
  /**
   *
   * @param {discord.Client} client
   * @param {discord.Message} message
   * @param {String[]} args
   */
  run: async (client, message, args) => {
    args = args.join(" ");
    let embed = new discord.MessageEmbed();
    embed.setTitle("Aguarde...");
    embed.setDescription(`${emoji.loading(client)} | Procurando...`);
    embed.setFooter(message.author.username, message.author.avatarURL());
    let msg = await message.channel.send(embed);
    let img = await imgur.search(args);
    let sl = Math.round(Math.random() * img.images.length);

    if (img.images[sl]) {
      embed.setImage(img.images[sl].link);
    } else {
      sl--;
      embed.setImage(img.images[sl].link);
    }
    embed.setTitle("ok!");
    embed.setDescription("");
    await msg.edit(embed);
  },
};
