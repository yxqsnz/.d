const google_image = require("../../api/GoogleApi");
const discord = require("discord.js");
const emoji = require("../../Scripts/Utils/Bot_Emojis.js");

module.exports = {
  name: "glimgsearch",
  aliases: ["simg", "search-img"],
  /**
   *
   * @param {discord.Client} client
   * @param {discord.Message} ctx
   * @param {String[]} args
   */
  run: async (client, ctx, args) => {
    //para de usar CTX FDP
    args = args.join(" ");
    let embed = new discord.MessageEmbed();
    if (!args || args == "") {
      await ctx.channel.send("Por favor bote um termo de pesquisa!");
      return;
    }

    embed.setTitle(`${emoji.loading2(client)} Pesquisando por "${args}"...`);
    embed.setColor("2f3136");

    const m = await ctx.channel.send(embed);
    const results = await google_image.searchImage(args, 10);
    const result_selected = Math.round(Math.random() * results.length);
    embed.setImage(results[result_selected]);
    embed.setDescription(`${emoji.ok(client)} Pronto!`);
    embed.setTitle("Nice!");
    embed.setTimestamp();
    embed.setThumbnail(results[result_selected].th);
    if (!results[result_selected].lk) {
      embed.setImage(results[result_selected].th);
    } else {
      embed.setImage(results[result_selected].lk);
    }

    embed.setURL(results[result_selected].lk);

    m.edit(embed);
  },
};
