

import discord = require('discord.js');
import Scraper = require('mal-scraper')
import String = require("../../Scripts/Utils/String")
module.exports ={
    name:"anime",
    description:"Pega informações de algum anime",
    usage:"<Anime>",
    run: async (client:discord.Client,message:discord.Message,args:String[]) =>{
    if(!args.length){
        message.channel.send("Por favor bote um nome!");
        return;
    }
        const AnimeName = args.join(" ");
       
      
    const embed = new discord.MessageEmbed();
    
  Scraper.getInfoFromName(AnimeName).then(async (anime) =>{

    const AnimeTitle = anime.title;
    const AnimeType = anime.type;
    const AnimePic = anime.picture;
   
    const AnimeId = anime.id;
    const AnimeImage = anime.image;
    const AnimeEpisodes = anime.episodes;
    const AnimeStatus = await String.translate(anime.status,'pt');
    const AnimeMembers = anime.members;
    const AnimePopul = anime.popularity;
    let AnimeSyno = anime.synopsis;
    let Animegenres = "";
    if(!AnimeSyno){
        AnimeSyno = "Sem...";
    }
    else{
     
        try{
        AnimeSyno = await String.translate(AnimeSyno,'pt')
        }catch(e){
            AnimeSyno = AnimeSyno.toString();
        }
    
    }
    const AnimeRating = anime.rating;
    const AnimeScore = anime.score;
    let AnimeStudios = "";
    for(const Studio of anime.studios){
        AnimeStudios += Studio;
    }
    for(const gender of anime.genres){
        Animegenres += gender + " ";
    }
    embed.setTitle(`Info do ${AnimeTitle}`);
    embed.setDescription(AnimeSyno);

    embed.addField("Classificação",AnimeRating,true);
    embed.addField("Score",AnimeScore,true);
    embed.addField("Popularidade",AnimePopul,true);
    embed.addField("Membros",AnimeMembers,true);
    embed.addField("Status",AnimeStatus,true);
    embed.addField("Episódios",AnimeEpisodes,true);
    embed.setThumbnail(AnimePic);
    embed.setImage(AnimeImage);
    embed.addField("Tipo",AnimeType,true);
    embed.addField("Gêneros",Animegenres,true);
    embed.addField("Id",AnimeId,true);
    embed.addField("Studios",AnimeStudios,true);

    embed.setURL(anime.url);
    message.channel.send(embed);
  }).catch(() =>{
      message.channel.send("Ocorreu Um erro.");
  })
       
     
    
    
    }
}