const emoji = require("../../Scripts/Utils/Bot_Emojis.js");
const imgur = require("../../api/Imgur");
const discord = require("discord.js");
module.exports = {
  name: "searchimgur",
  aliases: ["simgur"],
  description: "Pesquisa alguma coisa no  IMGUR",
  /**
   *
   * @param {discord.Client} client
   * @param {discord.Message} message
   * @param {String[]} args
   */
  run: async (client, message, args) => {
    if (!args) {
      await message.reply("uso: simgur <query>");
    }
    args = args.join(" ");

    let embed = new discord.MessageEmbed();
    embed.setColor(message.member.displayHexColor);
    embed.setTitle("Aguarde...");
    embed.setDescription(
      `${emoji.get_emoji(client, "bot_loading7")} | Procurando...`
    );
    embed.setFooter(message.author.username, message.author.avatarURL());
    let msg = await message.channel.send(embed);
    let img = await imgur.search(`${args}`);
    if (img) {
      if (img.images[0]) {
        embed.setTitle(img.title);

        embed.setDescription(
          `:thumbsup: ${img.ups} :thumbsdown: ${img.downs}\nauthor: ${img.account_url}\nviews ${img.images[0].views}   `
        );
        embed.setImage(img.images[0].link);

        if (img.nsfw) {
          await message.author.send(embed).catch();
          return;
        } else {
          await msg.edit(embed);
        }
      }
    } else {
      embed.setTitle("Erro");
      embed.setDescription("Não consegui encontrar..");
      await msg.edit(embed);
    }
  },
};
