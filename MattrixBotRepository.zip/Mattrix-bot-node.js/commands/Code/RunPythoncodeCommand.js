const { exec } = require("child_process");
const fs = require("fs");
const Timer = require("time-counter");

const { MessageEmbed, Message, Client } = require("discord.js");
module.exports = {
  name: "runpyc",
  category: "Code",
  aliases: ["rpyc"],
  description: "Rodar um código em python",

  /**
   * @param {Client} client
   * @param {Message} message
   * @param {String[]} args
   */

  run: async (client, message, args) => {
    // if (message.author.id == 450812271451439124 || message.author.id == 516724728086659072)
    // {
    //   await message.reply('you are in blacklist.')
    //   return
    // }
    const blocked = ["rm", "-rf", "shutdown", "reboot", "cat", "ls"];
    for (let i = 0; i < blocked.length; i++) {
      if (message.content.includes(blocked[i])) {
        message.channel.send("[ Mattrix Command Blocker ] - Comando Bloqueado");
        return;
      }
    }
    let embed = new MessageEmbed();
    embed.setTitle("Aguarde");
    embed.setColor("2f3136");
    embed.setFooter(message.author.username, message.author.avatarURL());
    embed.setTimestamp();
    const loading = client.emojis.cache.find(
      (emoji) => emoji.name === "bot_loading2"
    );
    const ok = client.emojis.cache.find((emoji) => emoji.name === "bot_ok");
    const error = client.emojis.cache.find(
      (emoji) => emoji.name === "bot_error"
    );

    args = args.join(" ");

    if (!args && args == "") {
      await message.reply("uso: rpyc <code>");
      return;
    }

    if (typeof args == "array") {
      n = "";
      for (i in args) {
        n += i;
      }
      args = n;
    }
    embed.setDescription(
      `${loading} Criando Script...\n${loading} Executando Script`
    );
    let msg = await message.channel.send(embed);
    fs.writeFile(
      `/tmp/code_${message.guild.id}_${message.author.id}.py`,
      args.toString(),
      function (err) {
        if (err) {
          embed.setDescription(
            `${error} Criando Script...\n${error} Executando Script`
          );
          msg.edit(embed);
          return;
        }
      }
    );
    embed.setDescription(
      `${ok} Criando Script...\n${loading} Executando Script`
    );
    msg.edit(embed);

    var c = new Timer();
    c.start();

    exec(
      `python /tmp/code_${message.guild.id}_${message.author.id}.py`,
      async (err, stderr, stdout) => {
        if (stdout) {
          stdout = Array(stdout).join(" ");
        } else {
          stdout = "Nenhum erro.";
        }

        if (stderr.toString().length >= 1024) {
          stderr = stderr.toString().substring(0, 1000);
          stderr += "...";
        }
        if (stdout.toString().length >= 1024) {
          stdout = stderr.toString().substring(0, 1000);
          stdout += "...";
        }

        let newstdout = "```py\n" + stdout.toString() + "```";
        if (stderr) {
        } else {
          stderr = "Nenhuma saida.";
        }

        let newsterr = "```py\n" + stderr.toString() + "```";

        c.stop();
        embed.setDescription(
          `${ok} Criando Script...\n${ok} Executando Script`
        );
        await msg.edit(embed);
        embed.setColor("RANDOM");
        embed.addField("Erros: ", newstdout, false);
        embed.addField("Saida: ", newsterr, false);
        embed.description =
          "Código terminado em: " +
          (c.stoppedTime - c.timerStartTime).toString() +
          " Ms";
        try {
          fs.rm(
            `/tmp/code_python_${message.guild.id}_${message.author.id}.py`,
            function () {}
          );
        } catch {}

        embed.setFooter(message.author.username, message.author.avatarURL());
        await message.channel.send(embed);
        msg.delete();
      }
    );
  },
};
