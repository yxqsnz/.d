import discord = require("discord.js");
import emoji = require("../../Scripts/Utils/Bot_emojis_ts");
module.exports = {
  name: "quickreact",
  description: "quem reage primero the game",
  run: async (
    client: discord.Client,
    message: discord.Message,
    args: String[],
    text
  ) => {
    const embed = new discord.MessageEmbed();
    embed.setColor("BLUE")
    embed.setTitle(
      `${await emoji.FindEmojiByName(client, "bot_loading")}`
    );
    const msg = await message.channel.send(embed);
    const member = message.mentions.users.first();
    if (!member) {
      embed.setTitle(`${emoji.error(client)} - ${text.getGuildLocale("MissingMemberMention")}`);
    
      msg.edit(embed);
      return;
    }
    if (member.bot)
    {
      embed.setTitle("Você não pode marcar um BOT!");
      msg.edit(embed);
      return;
      }
    let winner = "0";
    setTimeout(() => {
      embed.setTitle(text.getGuildLocale(message.guild.id,"Now"));
     
      msg.edit(embed);
      msg.react("😎");
      const filter = (reaction, user) => {
        if (reaction.emoji.name === "😎" && user.id != message.guild.me.id) {
          if (user.id == message.author.id || user.id == member.id)
          {
            return true;
          }
          else {
            return false;
          }
        }
        else {
          return false;
        }
      };

      const collector = msg.createReactionCollector(filter, { time: 5000 });

      collector.on("collect", (reaction, user) => {
        winner = user.tag;
        collector.emit("end");
      });

      collector.on("end", (collected) => {
        if (winner != "0") {
          collector.stop("Game over");

          embed.setTitle(`O ganhador foi ${text.getGuildLocale(client,"QRWinner",winner)}`);
          if (message.guild.me.hasPermission("MANAGE_EMOJIS"))
          {
            msg.reactions.removeAll();
            }
          msg.edit(embed);
        } else {
          collector.stop("Game over");
          if (message.guild.me.hasPermission("MANAGE_EMOJIS"))
          {
            msg.reactions.removeAll();
          }
          embed.setTitle(text.getGuildLocale(client,"QRNoWinner"));
          msg.edit(embed);
        }
      });
    }, Math.round(Math.random() * 5000));
  },
};
