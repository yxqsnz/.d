function UserException(message) {
    this.message = message;
    this.name = "UserException";
 }
const discord = require('discord.js');
module.exports = {
    name:"crash",
    minBotPermissions:["ADMINISTRATOR"],
    minPermissions:["DEV","ADMINISTRATOR"],
    run: async () =>{
        throw new TypeError("Error")
    }
}