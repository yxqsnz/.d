import * as discord from 'discord.js'
import * as database from '../../Scripts/Utils/database'
import * as emoji from '../../Scripts/Utils/Bot_emojis_ts'
    module.exports = {
    name : 'devbotinfo',
    aliases : ['dbi'],
    run : async(client:discord.Client, msg: discord.Message, args:string[]) => {
        async function getServer(){
            const server = client.guilds.cache.array().length
            return server
        }
        async function getServerName(){
            let names = ""
            const server = client.guilds.cache.array()
            for(let i = 0; i < server.length; i++){
                names += `${server[i].name}\n`
            }
            return names
        }
        
        if(msg.author.id == '567853754825572352' || msg.author.id == '450812271451439124'){
            
            const embed = new discord.MessageEmbed
            embed.addFields(
                {
                    name: "SERVIDORES", value: await getServer()
                },
                {
                    name: "SERVIDORES", value: await getServerName()
                },
                {
                    name: "USUARIOS", value: client.users.cache.array().length
                }
            )
            msg.channel.send(embed)
        }
        

    }

}
