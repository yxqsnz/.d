const discord = require('discord.js')
const  mgi = require('merge-img');
const mg2 = require('merge-images-v2');
const jimp = require('jimp')
const io = require('../../Controllers/IOController');
const canvas  = require('canvas')
module.exports ={
    name:"devi",
    /**
     * 
     * @param {*} cliente 
     * @param {discord.Message} message 
     * @param {*} args 
     */
    run: async(cliente,message,args) =>{
       await message.channel.send("await...")
        const background = await jimp.read("assets/backgrounds/profile.jpg");
        
        await message.channel.send("Loaded Background and Mask.")
        const status =  {
            dnd: await jimp.read("assets/status/dnd.png"),
            online: await  jimp.read("assets/status/on.png"),
            idle:  await jimp.read("assets/status/idle.png"),
            offline: await jimp.read("assets/status/off.png")
        }
        const avatar = await jimp.read(message.author.displayAvatarURL({format:'png',size:1024}));
        const userStatus =  status[message.author.presence.status];
        const font = await jimp.loadFont("Fonts/FiraCode.fnt");
        await message.channel.send("Loaded avatar and status.")
       try{
       await avatar.resize(449,309)
        
        await background.composite(avatar,2,10);
        await background.print(font,900,50,message.author.tag);
        await background.write('outi.png')
       }
       catch(e) {
           console.error(e);
           message.reply("An error has ocurred");
           return;
       }
       await message.channel.send("Ok");
        await message.channel.send('',{files:['outi.png']})
       
        
    }
}