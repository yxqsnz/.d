const Canvas = require('canvas');
const Discord = require('discord.js');
const Stackblur = require('stackblur-canvas')

/**
 * 
 * @param {Discord.Client} client 
 * @param {Discord.Message} message 
 * @param {*} args
 */
exports.run = async (client,message,args) => {
   
    Canvas.registerFont("Fonts/maxwell.ttf",{family:"REGULAR"});
    const canvas = Canvas.createCanvas(700, 250);
    const ctx = canvas.getContext('2d');


    const background = await Canvas.loadImage(message.guild.iconURL({format:"jpg",size:1024}))
    ctx.filter = "blur(50%)"
    ctx.drawImage(background, 0,0,canvas.width,canvas.height);
    ctx.strokeStyle = '#7289da';
	ctx.strokeRect(0, 0, canvas.width, canvas.height);


	ctx.font = '60px MAXWELL REGULAR';
	
	ctx.fillStyle = '#ffffff';
	
	ctx.fillText(message.author.username, canvas.width / 2.5, canvas.height / 1.8)
    
	ctx.beginPath();
	ctx.arc(125, 125, 100, 0, Math.PI * 2, true);
	ctx.closePath();
	ctx.clip()
    const avatar = await Canvas.loadImage(message.author.displayAvatarURL({ format: 'jpg',size:1024 }));
	
    ctx.drawImage(avatar, 25, 25, 200, 200);

    const attachment = new Discord.MessageAttachment(canvas.toBuffer(), 'welcome-image.png');
    message.channel.send(`Ok!!`, attachment);

}
exports.name = "devi2";