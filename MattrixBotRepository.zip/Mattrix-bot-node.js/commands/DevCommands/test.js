exports.name = "tst"
const Discord = require('discord.js');
/**
 * @param {Discord.Client} client
 */
exports.run = async(client,message) => {
client.emit("guildCreate",message.guild);
}