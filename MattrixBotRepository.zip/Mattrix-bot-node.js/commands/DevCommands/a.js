/*
const { MessageEmbed } = require('discord.js')
const moment = require('moment')
moment.locale('pt-br')
module.exports = {
    name: 'serverinfou',
    category: 'info',
    description: 'Retorna informações detalhadas sobre o servidor.',

    run: async(client, message, args) => {
        const verificationLevels = {
            NONE: 'Nenhum',
            LOW: 'Baixo',
            MEDIUM: 'Médio',
            HIGH: 'Alto',
            VERY_HIGH: 'Muito alto'
        }
        const regions = {
            brazil: 'Brasil',
            europe: 'Europa'
        }

        const members = message.guild.members.cache;
        const channels = message.guild.channels.cache;
        const emojis = message.guild.emojis.cache;

        const { guild } = message

        const {name, region, memberCount, owner} = guild

        const icon = guild.iconURL()

        const embed = new MessageEmbed()
        .setTitle(`📝 Informações de ${name}`)
        .setThumbnail(icon)
        .setColor('#42f542')
        .addField('> :book: Informações Gerais:', [
            ` \`\`\`➛ Nome: ${name}
➛ Dono: ${message.guild.owner.user.tag}
➛ Região: ${regions[message.guild.region]}
➛ ID: ${message.guild.id}
➛ Nv. Verificação: ${verificationLevels[message.guild.verificationLevel]}
➛ Criado em: ${moment(message.guild.createdTimestamp).format('LL')} ${moment(message.guild.createdTimestamp).format('LT')} ${moment(message.guild.createdTimestamp).fromNow()}\`\`\` `
            ])
        .addField('> :gear: Status:', [
            ` \`\`\`➛ Membros: ${message.guild.memberCount}
➛ Cargos: ${message.guild.roles.cache.size}
➛ Emojis: ${emojis.size}
➛ Canais: ${channels.size}
➛ Num. Boost: ${message.guild.premiumSubscriptionCount || '0'}\`\`\` `])
        message.channel.send(embed)
    }
}
*/