const discord = require('discord.js')
const  mgi = require('merge-img');
const mg2 = require('merge-images-v2');
const jimp = require('jimp')
const io = require('../../Controllers/IOController');
const canvas  = require('canvas')
module.exports ={
    name:"allguys",
    /**
     * 
     * @param {discord.Client} cliente 
     * @param {discord.Message} message 
     * @param {*} args 
     */
    run: async(cliente,message,args) =>{
       await message.channel.send("await...")
       const background = await (await jimp.read("assets/backgrounds/space.jpg")).resize(1024,800);
      const userAvatars = [];
      for (const avatar of cliente.users.cache.array()){

        userAvatars.push(await jimp.read(avatar.displayAvatarURL({format:'png'})))
        
      }
      let i = 0;
      let o = 0;
       try{
        for (const avatar of userAvatars){
            i++;
            o++;
            await background.composite(avatar,i,o);
            i = i + 80;
            o = o  + 80 ;
        }
       }
       catch(e) {
           console.error(e);
           message.reply("An error has ocurred");
           return;
       }
       await background.write("outi.png")
       await message.channel.send("Ok");
        await message.channel.send('',{files:['outi.png']})
       
        
    }
}