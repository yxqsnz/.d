const Canvas = require('canvas');
const Discord = require('discord.js');
module.exports = {
    name:"dieplague",
    aliases:["morrepraga","plague"],
    /**
     * 
     * @param {*} client 
     * @param {Discord.Message} message 
     * @param {*} args 
     */
    run: async (client,message,args) => {
        let user = message.mentions.users.first();

        if(!user){
            user = message.author;
        }
        const canvas = Canvas.createCanvas(700, 550);
        const ctx = canvas.getContext('2d');
     
        const background = await Canvas.loadImage("./assets/Edit/praga.jpg");
        ctx.drawImage(background, 0,0,canvas.width,canvas.height);
        const avatar = await Canvas.loadImage(user.avatarURL({ format: 'jpg',size:1024 }));
        
        ctx.drawImage(avatar, 25, 200, 300, 200);
    
        const attachment = new Discord.MessageAttachment(canvas.toBuffer(), 'diePlague.jpg');
        message.channel.send(``, attachment);
    }  
}
