const discord = require('discord.js')
const emoji = require( '../../Scripts/Utils/Bot_Emojis')
    module.exports = {
    name : 'report-bug',
    aliases : ['breport', 'b-report', 'reportb', 'bugreport'],
    /**
     * 
     * @param {discord.Client} client 
     * @param {discord.Message} msg 
     * @param {String[]} args 
     */
    run : async(client, msg, args) => {
        
        const error = emoji.error(client)
        const ok = emoji.ok(client)
        const loading = emoji.loading(client)
        const embed = new discord.MessageEmbed
        embed.setTitle(`${loading} Analisando seu report`)
        const m = await msg.channel.send(embed)
        
        if(!args[0]){
            embed.setTitle(`${error} NEGADO! você não colocou uma descrição`)
            return m.edit(embed)
        }

        const motivo = await args.slice(0).join(" ")
        if(motivo.length < 25){
            embed.setTitle(`${error} NEGADO! você colocou uma descrição muito pequena`)
            return m.edit(embed)
        }
        embed.setTitle(`${loading} Você tem certeza de que deseja enviar esse report?`)
        embed.addFields(
            {
                name: "Report", value: `${motivo}`
            },
            {
                name: "Reporter", value: `${msg.author.username}`
            }
            
        )
        const emojiReact = [ '✅','❌' ]
        m.react(emojiReact[0])
        m.react(emojiReact[1])
        m.edit(embed)
        const filter = (reaction, user) => {
            return reaction.emoji.name == emojiReact[0] || reaction.emoji.name == emojiReact[1]
        }
        function sendReport(){
            const report = new discord.MessageEmbed
            report.setTitle(`Novo bug reportado`)
            report.addFields(
                {
                    name: "Report", value: "```" + motivo + "```"
                },
                {
                    name: "Reporter", value: `${msg.author.username}`
                }
                
            )
            const guild = client.guilds.cache.get('775678690750103562')
            const message = client.channels.cache.find(c => c.id == 811278142467604480)
            message.send(report).then(mesg => {
                setTimeout(() => {
                    mesg.delete()
                }, 1000 * 60 * 60 * 24 * 7);
            })
            
           
            
            
        }
        
        const coletor = m.createReactionCollector(filter, {time: 50000})
        coletor.on('collect', (reaction, user) => {
            if(user.bot) return
            //console.log(reaction.emoji.name)
            //eu não entendo o JS pqp
            if(user.id != msg.author.id)
            console.log(user.id === msg.author.id)
                if(reaction.emoji.name ==  emojiReact[0]){

                    embed.setTitle(`${ok} Enviando Report!`)
                    embed.fields = []
                    m.edit(embed)
                    sendReport()
                    coletor.stop()
                }
                   
                if(reaction.emoji.name == "❌"){
                    embed.setTitle(`${ok} Parando o envio de report!`)
                    embed.fields = []
                    m.edit(embed)
                    coletor.stop()
                }
                   


            
        })
        


        
    }

}