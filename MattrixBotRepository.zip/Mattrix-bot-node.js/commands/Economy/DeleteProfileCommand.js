const emoji = require("../../Scripts/Utils/Bot_Emojis.js");
const database = require("../../Scripts/Utils/database.js");
const discord = require("discord.js");
module.exports = {
  name: "del-profile",
  aliases: ["deletar-profile", "del-perfil", "remove-profile"],
  /**
   *
   * @param {discord.Client} client
   * @param {discord.Message} msg
   * @param {*} args
   */
  run: async (client, msg, args) => {
    const Economy = await database.Client.db("Economy");
    const users = await Economy.collection("Users");

    const userd = await users.findOne({ user_id: msg.author.id });
    if (!userd) return msg.reply("Você não tem uma conta!");
    const embed = new discord.MessageEmbed();
    embed.setTitle(`Deletando Conta! ${emoji.loading2(client)}`);
    const message = await msg.channel.send(embed);
    await users.deleteOne({ user_id: msg.author.id.toString() });
    const hasAccount = await users.findOne({ user_id: msg.author.id });
    if (!hasAccount) {
      embed.setTitle(`Conta deletada com sucesso! ${emoji.ok(client)}`);
      embed.setDescription("Sua conta foi deletada com sucesso!");
      message.edit(embed);
    } else {
      embed.setTitle(
        `não foi possivel apagar sua conta! ${emoji.error(client)}`
      );
      embed.setDescription("Não foi possivel realizar esta operação");
      message.edit(embed);
    }
  },
};
