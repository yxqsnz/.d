const emoji = require("../../Scripts/Utils/Bot_Emojis.js");
const database = require("../../Scripts/Utils/database.js");
const discord = require("discord.js");

module.exports = {
  name: "pay",
  aliases: ["pagar", "transferir"],
  /**
   * @param {discord.Client} client
   * @param {discord.Message} msg
   */
  run: async (client, msg, args) => {
    let member = msg.guild.member(msg.mentions.users.first());
    const embed = new discord.MessageEmbed();
    embed.setTitle(`${emoji.loading2(client)} Carregando`);
    const message = await msg.channel.send(embed);
    if (!member) {
      embed.setTitle(`${emoji.error(client)} ERRO`);
      embed.setDescription("Você não mencionou ninguem!");
      return message.edit(embed);
    }
    if (member.id == msg.author.id) {
      embed.setTitle(`${emoji.error(client)} ERRO`);
      embed.setDescription("Você não pode transferir dinheiro para si mesmo");
      return message.edit(embed);
    }
    if (!args[1]) {
      embed.setTitle(`${emoji.error(client)} ERRO`);
      embed.setDescription("Você não definiu um valor!");
      return message.edit(embed);
    }
    const valor = parseInt(args[1]);
    const Economy = await database.Client.db("Economy");
    const users = await Economy.collection("Users");
    const memberDb = await users.findOne({ user_id: member.id });
    const authorDb = await users.findOne({ user_id: msg.author.id });

    if (!memberDb) {
      embed.setTitle(`${emoji.error(client)} ERRO`);
      embed.setDescription(
        `<@!${member.id}> não tem conta no bot! crie usando <prefix>cprofile`
      );
      return message.edit(embed);
    }
    if (!authorDb) {
      embed.setTitle(`${emoji.error(client)} ERRO`);
      embed.setDescription(
        `<@!${msg.author.id}> não tem conta no bot! crie usando <prefix>cprofile`
      );
      return message.edit(embed);
    }
    if (authorDb.money < valor) {
      embed.setTitle(`${emoji.error(client)} ERRO`);
      embed.setDescription(
        `<@!${msg.author.id}> não tem dinheiro suficiente para realizar esta transferencia!`
      );
      return message.edit(embed);
    }
    if (valor <= 0) {
      embed.setTitle(`${emoji.error(client)} ERRO`);
      embed.setDescription(`Não se pode transferir um valor menor que **0**`);
      return message.edit(embed);
    }
    if (isNaN(valor)) {
      embed.setTitle(`${emoji.error(client)} ERRO`);
      embed.setDescription(`Valor Invalido!`);
      return message.edit(embed);
    }
    await users.updateOne(
      {
        user_id: msg.author.id,
      },
      {
        $set: { money: authorDb.money - valor },
      }
    );
    await users.updateOne(
      {
        user_id: member.id,
      },
      {
        $set: { money: memberDb.money + valor },
      }
    );
    embed.setTitle(`${emoji.ok(client)} Trasnferido Com Sucesso!`);
    embed.setDescription(`Valor MM${valor} transferido com sucesso!`);
    message.edit(embed);
  },
};
