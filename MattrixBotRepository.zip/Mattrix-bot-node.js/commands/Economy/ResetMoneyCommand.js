const {Message, Client, MessageEmbed} = require("discord.js")
const emoji = require("../../Scripts/Utils/Bot_Emojis.js");
const database = require("../../Scripts/Utils/database.js");
module.exports = {
    name : "resetmoney",
    aliases : ['resetm', 'mmreset'],
    /**
     * @param {Client} client
     * @param {Message} msg
     * @param {String[]} args
     * 
     */
    run : async(client, msg, args) => {
        if(msg.author.id != "450812271451439124") return
        let userid = msg.mentions.users.first()
        if(!userid){
            userid = msg.author
        }
        const Economy = await database.Client.db("Economy");
        const users = await Economy.collection("Users");
        const userd = await users.findOne({ user_id: userid.id});
        const embed = new MessageEmbed
        embed.setTitle(`${emoji.loading2(client)} Carregando!`)
        const message = await msg.channel.send(embed)
        if(!userd){
            embed.setTitle(`${userid.username} não tem uma conta`)
            return message.edit(embed) 
        }
        
        
        
        message.edit(embed)
        
        if(await userd.money <= 0) 
        {
            embed.setTitle(`${emoji.error(client)} já está com a conta resetada ou sem dinheiro!`)
            return message.edit(embed)   
        }
        async function resetMoney(){
            await users.updateOne(
                {'user_id': userid.id},
                {
                    $set: {'money': 0}
                }
            )
        }
        const money = await userd.money
        await resetMoney()
        if(money <= 0){
            embed.setTitle(`${emoji.ok(client)} Resetado com sucesso!`)
            return message.edit(embed)
        }

        if(money > 0){
            embed.setTitle(`${emoji.error(client)} Não foi possivel resetar!`)
            return message.edit(embed)
        }
        
        
    }
}