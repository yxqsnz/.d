const emoji = require("../../Scripts/Utils/Bot_Emojis.js");
const database = require("../../Scripts/Utils/database.js");
const discord = require("discord.js");
module.exports = {
  name: "profileinfo",
  description: "Olhar tuas informações",
  aliases: ["money"],
  /**
   *
   * @param {discord.Client} client
   * @param {discord.Message} message
   * @param {*} args
   */
  run: async (client, message, args) => {
    let user = message.mentions.users.first();
    if (!user) {
      user = message.author;
    }
    const embed = new discord.MessageEmbed();
    embed.setTitle("Aguarde");
    embed.setTimestamp();
    embed.setColor(message.member.displayHexColor);
    embed.setDescription(`${emoji.loading(client)}| Aguarde...`);
    embed.setFooter(message.member.displayName, message.author.avatarURL());
    let msg = await message.channel.send(embed);
    database.db.then(async () => {
      const Economy = await database.Client.db("Economy");

      const users = await Economy.collection("Users");

      const userd = await users.findOne({ user_id: user.id });
      if (!userd) {
        embed.setTitle("Desculpe");
        embed.setDescription(`<@${user.id}> não tem uma conta`);
        msg.edit(embed);
        return;
      }

      embed.setDescription("");
      embed.setTitle("Informações de " + user.username);
      embed.addField("MMS: ", userd.money);
      embed.addField("MJOB: ", userd.job);

      userd.compras = userd.compras.toString();
      if (!userd.compras) {
        userd.compras = "O Usuário ainda não comprou nada...";
      }
      embed.addField("Compras", ` **${userd.compras}** `);
      await msg.edit(embed);
    });
  },
};
