const emoji = require("../../Scripts/Utils/Bot_Emojis.js");
const database = require("../../Scripts/Utils/database.js");
const discord = require("discord.js");
module.exports = {
  name: "cwork",
  aliases: ["choose-work", "escolher-trabalha", "etrab", "etrabalho", "cjob"],
  /**
   *
   * @param {discord.Client} client
   * @param {discord.Message} msg
   * @param {String[]} args
   */
  run: async (client, msg, args) => {
    const Economy = await database.Client.db("Economy");
    const users = await Economy.collection("Users");
    const userd = await users.findOne({ user_id: msg.author.id });
    if (!userd) {
      msg.channel.send(`${emoji.error(client)} Você ainda não tem conta!`);
      return;
    }
    let trabalhos = ["programador", "desempregado"]; //Coloque o nome dos trabalhos
    let trabId = ["2", "1"]; //coloque o ID
    let emojis = [];
    emojis[0] = "2️⃣";
    emojis[1] = "3️⃣";
    emojis[2] = "4️⃣";
    emojis[3] = "5️⃣";
    emojis[4] = "6️⃣";
    emojis[5] = "7️⃣";
    emojis[6] = "8️⃣";
    emojis[7] = "9️⃣";
    const embed = new discord.MessageEmbed();
    embed.setTitle(`${emoji.loading(client)} Carregando`);
    const message = await msg.channel.send(embed);
    let desc = `Trabalhos: \n`;
    for (let i = 0; i < trabalhos.length; i++) {
      desc += `${emojis[i]} = **${trabalhos[i].toUpperCase()}**\n`;
      await message.react(emojis[i]);
    }
    embed.setTitle("Reaja para conseguir o seu trabalho!");
    embed.setDescription(desc);
    message.edit(embed);
    const filter = (reaction, user) => {
      return user.id == msg.author.id;
    };
    let job_id = 0;
    async function insert(number) {
      await users.updateOne(
        { user_id: msg.author.id },
        { $set: { job: trabalhos[number] } }
      );
      await users.updateOne(
        { user_id: msg.author.id },
        { $set: { job_id: trabId[number] } }
      );
      embed.setTitle(`${emoji.ok(client)} Emprego Adicionado!`);
      embed.setDescription(`Seu novo emprego foi adicionado`);
      message.edit(embed);
    }
    const coletor = message.createReactionCollector(filter, { time: 50000 });
    coletor.on("collect", (reaction, user) => {
      for (let i = 0; i < emojis.length; i++) {
        if (reaction.emoji.name == emojis[i]) {
          insert(i);
          break;
        }
      }
      coletor.stop();
    });
  },
};
