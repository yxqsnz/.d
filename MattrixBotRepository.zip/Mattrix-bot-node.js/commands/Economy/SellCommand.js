const emoji = require("../../Scripts/Utils/Bot_Emojis.js");
const database = require("../../Scripts/Utils/database.js");
const discord = require("discord.js");
module.exports = {
  name: "vender",
  aliases: ["sell"],
  description: "veenda produtos",
  usage: "<produto> <preco> <stock> <descrição>",
  /**
   * @param {discord.Message} msg
   * @param {discord.Client} client
   * @param {String[]} args
   */
  run: async (client, msg, args) => {
    //vender <produto> <preco> <stock> <descrição>
    //Ao Comprar Adicionar na lista!
    const embed = new discord.MessageEmbed();
    embed.setTitle(`${emoji.loading(client)} Carregando`);
    const message = await msg.channel.send(embed);

    if (!args[0]) {
      embed.setTitle(`${emoji.error(client)} ERRO`);
      embed.setDescription(`Você não definiu um Produto!`);
      return message.edit(embed);
    }
    const produto = args[0];
    if (!args[1]) {
      embed.setTitle(`${emoji.error(client)} ERRO`);
      embed.setDescription(`Você não definiu um preço`);
      return message.edit(embed);
    }
    const valor = parseInt(args[1]);
    if (!args[2]) {
      embed.setTitle(`${emoji.error(client)} ERRO`);
      embed.setDescription(`Você não definiu um Quantos produtos!`);
      return message.edit(embed);
    }
    const Stock = parseInt(args[2]);
    let desc = args.slice(0).slice(0).slice(0);
    if (args[3]) {
      desc = desc[3];
    }
    if (isNaN(valor)) {
      embed.setTitle(`${emoji.error(client)} ERRO`);
      embed.setTitle("Você colocou um valor invalido");
      return message.edit(embed);
    }
    if (isNaN(valor)) {
      embed.setTitle(`${emoji.error(client)} ERRO`);
      embed.setTitle("Você colocou um stock invalido");
      return message.edit(embed);
    }
    embed.setTitle(`Produto de ${msg.author.username}`);
    const Economy = await database.Client.db("Economy");

    const produtos = await Economy.collection("Produtos");
    const users = await Economy.collection("Users");
    const userd = await users.findOne({ user_id: msg.author.id });
    if (!userd) {
      embed.setTitle(`${emoji.error(client)} ERRO`);
      embed.setDescription(
        `Você não tem uma conta! crie usando <prefixo>cprofile`
      );
      return message.edit(embed);
    }
    async function genProductId() {
      let produtoId = Math.random().toString().slice(-5);
      const buscaId = await produtos.findOne({ produto_id: produtoId });
      if (buscaId) {
        await genProductId();
      } else {
        return produtoId;
      }
    }
    const produtoId = await genProductId();
    await produtos.insertOne({
      produto_id: produtoId,
      preco: valor,
      Quantidade: Stock,
      Nome: produto,
      VendedorId: msg.author.id,
    });
    
    const buscaId = await produtos.findOne({ produto_id: produtoId });
    embed.setTitle(`${emoji.ok(client)} Produto de ${msg.author.username}`);
    embed.addFields(
      {
        name: "Produto",
        value: `${produto}`,
      },
      {
        name: "Preço",
        value: valor,
      },
      {
        name: "Quantidade",
        value: Stock,
      },
      {
        name: "Como Comprar",
        value: `<prefixo>comprar ${buscaId.produto_id}`,
      }
    );
    message.edit(embed);
  },
};
