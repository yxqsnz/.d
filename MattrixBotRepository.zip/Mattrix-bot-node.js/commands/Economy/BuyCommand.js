const database = require("../../Scripts/Utils/database.js");
const discord = require("discord.js");
const emoji = require("../../Scripts/Utils/Bot_Emojis.js");
module.exports = {
  name: "comprar",
  aliases: ["buy"],
  usage: "<id>",
  /**
   *
   * @param {discord.Client} client
   * @param {discord.Message} msg
   * @param {String[]} args
   */
  run: async (client, msg, args) => {
    const embed = new discord.MessageEmbed();
    embed.setTitle(`${emoji.get_emoji(client, "bot_sp_cart")} Comprando...`);
    const message = await msg.channel.send(embed);
    const Economy = await database.Client.db("Economy");
    const produtos = await Economy.collection("Produtos");
    const users = await Economy.collection("Users");
    const userd = await users.findOne({ user_id: msg.author.id });
    embed.setDescription(
      `${emoji.loading(client)} |> Verificando...\n${emoji.loading(
        client
      )} |> Modificando...`
    );
    await message.edit(embed);
    if (!userd) {
      embed.setTitle(`${emoji.error(client)} ERRO`);
      embed.setDescription(
        `Você não tem uma conta! crie usando <prefixo>cprofile`
      );
      return message.edit(embed);
    }
    if (!args[0]) {
      embed.setTitle(`${emoji.error(client)} ERRO`);
      embed.setDescription(`Você não colocou um ID`);
      return message.edit(embed);
    }
    const buscaId = await produtos.findOne({ produto_id: args[0] });

    if (!buscaId) {
      embed.setTitle(`${emoji.error(client)} ERRO`);
      embed.setDescription(`Você não colocou um ID válido!`);
      return message.edit(embed);
    }
    if (userd.money < buscaId.preco) {
      embed.setTitle(`${emoji.error(client)} ERRO`);
      embed.setDescription(
        `Você não tem Dinheiro suficiente para realizar esta compra!`
      );
      return message.edit(embed);
    }
    const vendedor = await users.findOne({ user_id: buscaId.VendedorId });
    if (buscaId.VendedorId == msg.author.id) {
      embed.setTitle(`${emoji.error(client)} ERRO`);
      embed.setDescription("Você não pode comprar de si mesmo!");
      return message.edit(embed);
    }
    if (buscaId.Quantidade <= 0) {
      embed.setTitle(`${emoji.error(client)} ERRO`);
      embed.setDescription("o Estoque desse produto acabou!");
      return message.edit(embed);
    }
    embed.setDescription(
      `${emoji.ok(client)} |> Verificando...\n${emoji.loading(
        client
      )} |> Modificando...`
    );
    await message.edit(embed);
    await users.updateOne(
      { user_id: msg.author.id },
      { $set: { money: userd.money - buscaId.preco } }
    );

    let name = await buscaId.Nome;

    await users.updateOne(
      { user_id: msg.author.id },
      { $set: { compras: userd.compras + " | " + name } }
    );
    await produtos.updateOne(
      { produto_id: args[0] },
      {
        $set: { Quantidade: buscaId.Quantidade - 1 },
      }
    );

    if (!vendedor)
      return msg.reply("Ocorreu um erro (mudar essa mensagem dps)");
    await users.updateOne(
      { user_id: buscaId.VendedorId },
      {
        $set: { money: vendedor.money + buscaId.preco },
      }
    );
    
    let awman = "";
    embed.setColor("FFD700");
    let restante = await buscaId.Quantidade - 1 
    if (buscaId.Quantidade <= 0) {
      awman = "Acabou os produtos!";
    } else {
      awman = `:shopping_cart: | Quantidade restante: **${restante}**`;
    }
    embed.setDescription(
      `:smiley: | Cliente: **${msg.author}**\n:grinning: | Vendedor: **<@${buscaId.VendedorId}>**\n:dollar: | Por: **${buscaId.preco}** MM(S)\n${awman}`
    );
    embed.setTitle(
      `${emoji.get_emoji(client, "bot_ok2")} Você comprou com sucesso!`
    );
    message.edit(embed);
    async function deleteProduto(){
      produtos.deleteOne(
        {'Quantidade': 0},
        {'preco': buscaId.preco},
        {'Nome': buscaId.Nome},
        {'VendedorId': buscaId.VendedorId},
        {'produto_id': buscaId.produto_id}
      )

    }
    if(restante == 0){
      deleteProduto()
    }
  },
};
