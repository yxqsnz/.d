const database = require("../../Scripts/Utils/database.js");
const discord = require("discord.js");
const emoji = require("../../Scripts/Utils/Bot_Emojis.js");
module.exports = {
  name: "cprofile",
  aliases: [
    "criar-profile",
    "criar-perfil",
    "make-profile",
    "criar-conta",
    "conta",
  ],
  /**
   *
   * @param {discord.Client} client
   * @param {discord.Message} msg
   * @param {*} args
   */
  run: async (client, msg, args) => {
    const Economy = await database.Client.db("Economy");
    const users = await Economy.collection("Users");
    const userd = await users.findOne({ user_id: msg.author.id });
    if (userd) return msg.reply("Você já tem uma conta!");
    const embed = new discord.MessageEmbed();
    embed.setTitle(`Criando Conta! ${emoji.loading(client)}`);
    const message = await msg.channel.send(embed);
    users.insertOne({
      user_id: msg.author.id,
      money: 0,
      job: "desempregado",
      compras: "",
      job_id: "1",
      background:0,
      premium:'false',
      backgrounds: []
    });

    embed.setTitle(`Conta criada com sucesso! ${emoji.ok(client)}`);
    embed.setDescription("Sua conta foi criada com sucesso!");
    message.edit(embed);
  },
};
