const DataBase = require("../../Scripts/Utils/database");
const Canvas = require('canvas');
const Discord = require("discord.js");
const acc = require("../../Scripts/Utils/TH_Account");
exports.name = "rank"
/**
 * @param {Discord.Client} client
 * @param {Discord.Message} message
 * @param {String[]} args
 */
exports.run = async (client,message,args) =>{
    message.channel.startTyping();
    Canvas.registerFont("Fonts/maxwell.ttf",{family:"REGULAR"});
    const canvas = Canvas.createCanvas(1224,900);
    const ctx = canvas.getContext("2d");
    ctx.filter = "blur(50%)"
    const background = await Canvas.loadImage("assets/backgrounds/rank.jpg");
    ctx.drawImage(background, 0,0,canvas.width,canvas.height);
    const Economy = DataBase.Client.db("Economy").collection("Users");
    const b = await Economy.find().sort({money: -1}).limit(10).toArray()
    function Rank(){
        for(const pos in b){
            if(b[pos].money){

                if(!b[pos].money ) b.pop();
                if(b[pos].money <= 0) b.pop();
            }
        }
       
    }
    // const userMoneys = []
  
    // for(const item of b){
    //    const OBJ = {
    //         user_id: item.user_id,
    //         money: item.money
    //    }
    //     userMoneys.push(OBJ);
       
    // }

    // userMoneys.sort();
    // userMoneys.reverse()
    Rank();
    let currenty = 0;
    for(pos in b){
       
        const CU_OBJ = {
            user_id: b[pos].user_id,
            money: b[pos].money,
            background: await acc.getUserBackground(b[pos].user_id),
        }
        const u = client.users.resolve(CU_OBJ.user_id);
        if(u){
            const background = await Canvas.loadImage(CU_OBJ.background);
            const avatar = await Canvas.loadImage(u.displayAvatarURL({ format: 'png',size: 1024 }));
            ctx.drawImage(background, 0, currenty,canvas.width, 200);
            ctx.drawImage(avatar, 0, currenty, 370, 200);
            ctx.font = '70px MAXWELL REGULAR';
	        ctx.fillStyle = '#ffffff';
            
	        if(currenty == 0){
             
                ctx.fillText(`MMS: ${CU_OBJ.money}`, 400, 100)
                ctx.fillText(u.tag, 400, currenty + 170)
            }
            else{
             
                ctx.fillText(`MMS: ${CU_OBJ.money}`, 400, currenty + 100)
                ctx.fillText(u.tag, 400, currenty + 170)
            }
    
            currenty += 190;
        }
       
    }
    const attachment = new Discord.MessageAttachment(canvas.toBuffer(), 'RANK.png');
    message.channel.send(``, attachment);
    message.channel.stopTyping();
}