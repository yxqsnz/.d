const emoji = require("../../Scripts/Utils/Bot_Emojis.js");
const database = require("../../Scripts/Utils/database.js");
const discord = require("discord.js");
const work = require("./working/wkconfig.js");
module.exports = {
  name: "work",
  description: "Trabalhar",
  /**
   *
   * @param {discord.Client} client
   * @param {discord.Message} ctx
   * @param {String[]} args
   */
  run: async (client, ctx, args) => {
    async function EarnMoney(MaxMoney) {
      return Math.floor(Math.random() * parseInt(MaxMoney));
    }
    const embed = new discord.MessageEmbed();
    embed.setTitle("Trabalhando...");
    embed.setDescription(`${emoji.loading(client)}| Aguarde...`);
    embed.setTimestamp();
    embed.setColor(ctx.member.displayHexColor);
    embed.setFooter(ctx.member.displayName, ctx.author.avatarURL());
    const msg = await ctx.channel.send(embed);
    database.db.then(async () => {
      const Economy = await database.Client.db("Economy");
      const users = await Economy.collection("Users");
      const member = await users.findOne({ user_id: ctx.author.id });

      if (!member) {
        embed.setTitle("Erro");
        embed.setDescription("você não tem um perfil!");
        await msg.edit(embed);
        return;
      }
      //JOB-ID:
      /**
       * 1 = Desempregado!
       * 2 = Programador!
       * o resto em breve
       */
      if (work.CurrentlyWorking.includes(ctx.author.id)) {
        embed.setTitle(`${emoji.error(client)} ERRO`);
        embed.setDescription("Parece que você já está trabalhando!");
        msg.edit(embed);
        return;
      } else {
        work.CurrentlyWorking.push(ctx.author.id);
      }
      switch (member.job_id) {
        case "1":
          embed.setTitle("Voce esta desempregado!");
          embed.setDescription(emoji.error(client));
          work.CurrentlyWorking.splice(
            work.CurrentlyWorking.indexOf(ctx.author.id),
            1
          );
          msg.edit(embed);

          break;
        case "2":
          embed.setTitle(`${emoji.loading(client)} Programando`);
          embed.setDescription("Trabalhando ");
          msg.edit(embed);
          let quantia = await EarnMoney(40);

          setTimeout(() => {
            embed.setTitle(`${emoji.ok(client)} Programado com sucesso`);
            embed.setDescription(`Você conseguiu ${parseInt(quantia)} MM`);
            embed.setImage(
              "https://media.tenor.com/images/545516438edd8e04c85112cba828f7c4/tenor.gif"
            );
            msg.edit(embed);

            work.CurrentlyWorking.splice(
              work.CurrentlyWorking.indexOf(ctx.author.id),
              1
            );
          }, 10000);
          await users.updateOne(
            {
              user_id: ctx.author.id,
            },
            {
              $set: { money: member.money + parseInt(quantia) },
            }
          );
          break;
        case "3":
          break;
        case "4":
          break;
        case "9":
          break;
        default:
          break;
      }
    });
  },
};
