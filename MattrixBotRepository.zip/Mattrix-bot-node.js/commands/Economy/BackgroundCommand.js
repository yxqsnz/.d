const Discord = require('discord.js');
const SubCommand = require('../../Scripts/handler/RunSubCommand');
module.exports = {
    name:"background",
    description:"Comprar um background",
    usage: "<set/buy>",
    run: async (client,message,args,text) => {
        if(!args.length){
            return message.reply(text.getGuildLocale(message.guild.id,"BackgroundMissingSubCommand"))
        }
            switch(args[0]){
                case 'set' || 'setar':
                    SubCommand.Run('set',client,message,args);
                    break;
                case 'buy'|| 'comprar':
                    SubCommand.Run('buy',client,message,args);
                    break;
                default:
                    return message.reply(text.getGuildLocale(message.guild.id,"InvalidSubCommand"))
            }
    }   
}