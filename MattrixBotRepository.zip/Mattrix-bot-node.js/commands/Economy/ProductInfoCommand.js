const emoji = require("../../Scripts/Utils/Bot_Emojis.js");
const database = require("../../Scripts/Utils/database.js");
const discord = require("discord.js");
module.exports = {
  name: "pinfo",
  aliases: ["produto-info", "info-produto"],
  /**
   *
   * @param {discord.Client} client
   * @param {discord.Message} msg
   * @param {String[]} args
   */
  run: async (client, msg, args) => {
    const embed = new discord.MessageEmbed();
    embed.setTitle(`${emoji.loading2(client)} Carregando`);

    const message = await msg.channel.send(embed);
    const Economy = await database.Client.db("Economy");
    const produtos = await Economy.collection("Produtos");
    const buscaId = await produtos.findOne({ produto_id: args[0] });
    if (!buscaId) {
      embed.setTitle(`${emoji.error(client)} ERRO`);
      embed.setDescription(`Você não colocou um ID válido!`);
      return message.edit(embed);
    }
    embed.setTitle(`${emoji.ok(client)} Aqui vai as Informações do produto!`);
    embed.addFields(
      {
        name: "ID",
        value: args[0],
      },
      {
        name: "Estoque",
        value: buscaId.Quantidade,
      },
      {
        name: "Vendedor",
        value: `<@!${buscaId.VendedorId}>`,
      },
      {
        name: "Preço",
        value: buscaId.preco,
      },
      {
        name: "Nome Do Produto",
        value: buscaId.Nome,
      }
    );
    message.edit(embed);
  },
};
