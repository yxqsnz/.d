const { random } = require("colors")
const discord = require("discord.js")
const content = require("../../api/Nekos.Life");
let ImageURL ="";

// tewdawdawd
module.exports = {
    name : "plus18",
    aliases : ['18+',"nsfw"],
    usage : "<pussy/hentai>",
    /**
     * @param {discord.Client} client
     * @param {discord.Message} msg
     * @param {String[]} args
     */
    run : async(client, msg, args) => {
        try{
        const embed = new discord.MessageEmbed
        const contents = ['hentai', 'pussy','hentaiGif',"futanari","feet",'feetGif',"neko","nekoGif","lesbian","pussyArt","pussyWankGif","trap","boobs"]
        let choice = args[0]
        if(!msg.channel.nsfw){
            if(!msg.member.hasPermission("MANAGE_CHANNELS")){
                embed.setTitle("ERR!");
            embed.setDescription("Desculpe esse comando é NSFW.\nPara usar o canal tem que ter ativo o NSFW!");
            msg.channel.send(embed);
            return;
            }
            else{
                embed.setTitle("ERR!");
                embed.setDescription('Desculpe esse comando é NSFW\nPara usar ative o NSFW nas configurações do canal.');
                msg.channel.send(embed);
                return;
            }
        }
        const emojiReact = ["🔄"  ]
        if(!args[0]){
            let random = contents[Math.floor(Math.random() * contents.length)]
            choice = random
        }   
        if(!choice.includes(contents)){
            let random = contents[Math.floor(Math.random() * contents.length)]
            choice = random
        }
      

        for (let cat of contents){
            if (args[0] == cat){
                choice = args[0];
                break;
            }
        }
        ImageURL = await getMedia(choice);
        async function getImage(){
            
            const {url} = await content.nsfw.hentai()
            return url
        }
        async function getMedia(s)
        {
            switch (s){
                case 'hentai':
                    return {url} = await content.nsfw.hentai()
                    return url
                    break;
                case 'hentaiGif':
                    return {url} = await content.nsfw.randomHentaiGif();
                    return url
                    break;
                case 'futanari':
                    return {url} = await content.nsfw.futanari();
                    return url
                    break;
                case 'feet':
                    return {url} = await content.nsfw.feet
                    
                    break;
                case 'feetGif':
                    return {url} = await content.nsfw.feetGif()
                    return url    
                case 'neko':
                    return {url} = await content.nsfw.neko()
                 
                case 'nekoGif':
                    return {url} = await content.nsfw.nekoGif()
                  
                case 'lesbian':
                    return {url} = await content.nsfw.lesbian();
           
                case 'pussyWankGif':
                    return {url} = await content.nsfw.pussyWankGif;
                    return url
                case 'pussyArt':
                    return {url} = await content.nsfw.pussyArt()
                    return url
                case 'pussy':
                    return {url} = await content.nsfw.pussy();
                case 'trap':
                    return {url} = await content.nsfw.trap
                    return url
                case 'boobs':
                    return {url} = await content.nsfw.boobs
                    return url
                default:
                    return null
            }
        }
        try{

        
        if(!ImageURL || !ImageURL.url){
           while (!ImageURL || !ImageURL.url)
           {
            let random = contents[Math.floor(Math.random() * contents.length)]
            choice = random
           }
        }
    }
    catch{}
        try{
        embed.setImage(ImageURL.url);
        embed.setTitle(`${choice}`);
        }
        catch{

        }
        const m = await msg.channel.send(embed)
        const filter = (reaction, user) => {
            return  user.id == msg.author.id
        }
        async function removeReaction(reaction, id){
            try{
            await m.reactions.cache.get(reaction).users.remove(id)
            }
            catch{

            }
        }
  
       try{
        m.react(emojiReact[0])
        m.react("811641519948693545")
       }
       catch{

       }
        const coletor = m.createReactionCollector(filter, {time: 50000})
        coletor.on('collect', async (reaction, user) => {

            if(reaction.emoji.name == emojiReact[0]){
                ImageURL = await getMedia(choice);
                embed.setImage(ImageURL.url);
                await m.edit(embed)
                
            }
            
            if(reaction.emoji.name == "bot_download"){
               const e = new discord.MessageEmbed()
                try{
        
                    e.attachFiles(ImageURL.url)
               }
               catch{
                   msg.channel.send("Error.");
                   return;
               }
        
               
                try{   msg.channel.send(e)}catch{
                    msg.channel.send("Error.");
                    return;
                }
             
            }
              
            removeReaction(emojiReact[0], user.id);
            removeReaction("811641519948693545", user.id);
        })
    }catch{
    
    }
}
}
