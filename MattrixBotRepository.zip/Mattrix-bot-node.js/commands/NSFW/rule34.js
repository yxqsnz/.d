const r34 = require("../../api/Rule34");
const discord = require('discord.js');
module.exports ={
    name:"rule34",
    description:"Search rule34.",
    aliases:['r34'],
    run:async(client,message,args)=>{
        const Embed = new discord.MessageEmbed();
        if(!message.channel.nsfw){
            Embed.setTitle("This command need NSFW enabled.");
            message.channel.send(Embed);
            return
        }
        Embed.setColor("GREEN");
        const query = args.join("_");
        if(!args.length){
            Embed.setTitle("Please tell me a query!");
            message.reply(Embed);
            return;
        }
        const result = await r34.Search(query);
        if(!result){
            Embed.setTitle("404 - Not found.");
            message.channel.send(Embed);
            return;
        }
       Embed.setThumbnail(result.thumbnail);
       Embed.setTitle("Rule34");
       Embed.setImage(result.img[0]);
       Embed.setFooter(result.id);
       message.channel.send(Embed);
    }
}