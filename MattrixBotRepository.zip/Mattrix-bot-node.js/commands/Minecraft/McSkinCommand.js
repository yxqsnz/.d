
const a = require("../../Scripts/Utils/Utils")
const { NameMC } = require("namemcwrapper");
const discord = require('discord.js')
module.exports = {
    name: "mcskin",
    description: "Pega uma skin de um jogador de minecraft",
    usage: "<NOME>",
 
    /**
     * 
     * @param {discord.Client} client 
     * @param {a.Message} message 
     * @param {String[]} args 
     */
    run: async (client, message, args) => {
        const nmc = new NameMC();

       
        if (!args.length) {
            message.inlineReply("Faltando argumento necessário");
            return;
        
        }
    const n = args[0]
        message.channel.startTyping()
        const skin = await  nmc.skinHistory({ nickname: n })
            .then((skins) => { return skins[0].url;
     })
    .catch((error) => console.log(error));
        message.channel.stopTyping(true)
        
        if (!skin)
        {
            message.inlineReply("Nome invalido!");
            return;
        };
        const embed = new discord.MessageEmbed()
        embed.setTimestamp()
        embed.setTitle(`Skin de ${n}`)
        embed.setColor("GREEN");
        
        embed.setImage(skin);
        message.channel.send(embed);
    }

}