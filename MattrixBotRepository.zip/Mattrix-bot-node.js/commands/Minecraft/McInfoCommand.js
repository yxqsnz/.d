
const a = require("../../Scripts/Utils/Utils")
const { NameMC } = require("namemcwrapper");
const discord = require('discord.js')
module.exports = {
    name: "mcinfo",
    description: "Pega uma Informações de um jogador de minecraft",
    usage: "<NOME>",
 
    /**
     * 
     * @param {discord.Client} client 
     * @param {a.Message} message 
     * @param {String[]} args 
     */
    run: async (client, message, args,text) => {
        const nmc = new NameMC();

       
        if (!args.length) {
            message.inlineReply(text.getGuildLocale(client,"MissingRequiredArgument","name"));
            return;
        
        }
        console.log(1)
    const n = args[0]
        message.channel.startTyping()
        const info  = await nmc.getPlayerInfo(n)
            .then((info) =>{return info})
            .catch((error) => console.log(error));
      
        message.channel.stopTyping(true)
       
        if (!info)
        {
            message.inlineReply(text.getGuildLocale(message.guild.id,"MinecraftInvalidName"));
           
            return;
        };
        const embed = new discord.MessageEmbed()
        embed.setTimestamp()
        embed.setTitle(text.getGuildLocale(message.guild.id,"InfoOf",n));
        embed.setColor("GREEN");
        let friends = "";
        for (let friend of info.friends) {
            friends += `${friend.name}\n`            
        }
          if (friends.length >= 1024)
        {
            friends = friends.substring(0, 1000);
            friends += "..."
          }
         if (!friends.length || friends == "") {
            friends = text.getGuildLocale(message.guild.id,"MinecraftNoFriends");
           
        }
        const total_skins = info.skins.length;
        const total_friends = info.friends.length;
        const total_capes = info.capes.length;
        const EmbedText = text.getGuildLocale(message.guild.id,"MinecraftUserInfoEmbed");
        const EmbedTextArray = EmbedText.split("::");
        embed.addField(EmbedTextArray[0], friends, false);
        embed.addField(EmbedTextArray[1], total_skins, false);
        embed.addField(EmbedTextArray[2], total_friends, false);
        embed.addField(EmbedTextArray[3], total_capes);
        embed.addField("SKIN", info.skins[0].url, false);
        
        if (info.capes[0])
        {
            embed.addField(EmbedTextArray[4], info.capes[0].url);    
        }
        message.channel.send(embed);
        
    }

}