import * as discord from 'discord.js'
module.exports = {
    name : "id",
    run : async(client:discord.Client, msg:discord.Message, args:string[]) =>{
        let user = msg.mentions.users.first()
        if(!user){
            user = msg.author
        }
        const embed = new discord.MessageEmbed()
        embed.setTitle(`ID de ${user.username}`)
        embed.setDescription(`**${user.id}**`)
        msg.channel.send(embed)
    }
        
        
    
}