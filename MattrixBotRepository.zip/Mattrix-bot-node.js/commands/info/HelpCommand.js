
const discord = require("discord.js");
const { readdirSync } = require("fs");
const config = require("../../Controllers/ConfigController")
module.exports = {
  name: "help",
  aliases: ["h"],
  usage:"[Comando]",
  description: "Mostra todos os comandos do bot",
  run: async (client, message, args,text) => {
    let prefix = config.LoadSettings(message.guild.id).prefix;

    if (!prefix) prefix = "th!";
    if (!message.guild) {
      let prefix = "th!";
    }
    const msg = message.channel.send("...")
    
    const roleColor = message.guild.me.displayHexColor;

    if (!args[0]) {
      let categories = [];

      readdirSync("./commands/").forEach((dir) => {
        const commands = readdirSync(`./commands/${dir}/`).filter(
          (file) => file.endsWith(".js") || file.endsWith(".ts")
        );

        const cmds = commands.map((command) => {
          let file = require(`../../commands/${dir}/${command}`);

          if (!file.name) return "404";

          let name = file.name.replace(".js", "");
          name = file.name.replace(".ts", "");

          return `\`${name}\``;
        });

        let data = new Object();
        const cat = require(`../../commands/${dir}/category.json`);
        if(cat.show == false)
        {
          return;
        }
        else if (cat.isNSFW == true && !message.channel.nsfw){
          return;
        }
        else{
          data = {
            name: cat.name,
            description:cat.description,
            value: cmds.length === 0 ? "Sem comandos ainda." : cmds.join(" "),
          };
  
          categories.push(data);
        }
      
      
        
      });
      let currentPage = 0
      const embed = new discord.MessageEmbed()
        .setTitle(text.getGuildLocale(message.guild.id,"HelpTitle"))
      
        .setThumbnail(client.user.avatarURL())
        .setDescription(text.getGuildLocale(message.guild.id,"HelpDescription",prefix))
        .setFooter(
          `${message.author.tag}`,
          message.author.displayAvatarURL({ dynamic: true })
        )
        .setTimestamp()
        .setColor(roleColor);
      embed.addField("help!",text.getGuildLocale(message.guild.id,"HelpGoPages"))
      embed.setImage("https://cdn.discordapp.com/attachments/775678690750103565/810865617862918144/IMG_20210215_102749.png");
      (await msg).react("▶️")
         const filter = (reaction, user) => {
        return  user.id == message.author.id
          
         };
      
      const collector = (await msg).createReactionCollector(filter, { time: 105000 });
      collector.on("end", async (collected) => {
        (await msg).delete()
      })
      collector.on("collect", async (reaction, user) => {
      
        if (user.id != message.guild.me.id)
        {
      ''
        
          if (message.guild.me.hasPermission("MANAGE_MESSAGES")) {
            (await msg).reactions.cache.get(reaction.emoji.name).users.remove(user.id);
          }
          
        }
         if (reaction.emoji.name === "◀️"){
          embed.fields.pop()
          if (currentPage != 0 )
          {
            embed.setFooter(`${message.author.username}| P: ${currentPage}/${categories.length -1}`,message.author.avatarURL())
            currentPage--;
              embed.setDescription(categories[currentPage].description)
             embed.addField(categories[currentPage].name, categories[currentPage].value);
           return (await msg).edit(embed);
            }
          else {
            if (message.guild.me.hasPermission("MANAGE_MESSAGES"))
            {
              (await msg).reactions.removeAll();
              (await msg).react("▶️")
              return
            }
            return
          }

          }
 
        if (reaction.emoji.name === "▶️")
        {
          
          embed.fields.pop()
          if (!(currentPage == categories.length -1))
          {
            currentPage++;
            embed.setFooter(`${message.author.username}| P: ${currentPage}/${categories.length -1}`,message.author.avatarURL())
            if (!categories[currentPage]) return;
            embed.setDescription(categories[currentPage].description)
            embed.addField(categories[currentPage].name, categories[currentPage].value);
           return (await msg).edit(embed);
            }
          else {
         
          if (message.guild.me.hasPermission("MANAGE_MESSAGES")) {
            await (await msg).reactions.cache.get("▶️").remove();
          }
          
        
             await (await msg).react("◀️")
            return
          }
         
          
         
        }
             });
      (await msg).edit("** **");
      (await msg).edit(embed);
    } else {
      const command =
        client.commands.get(args[0].toLowerCase()) ||
        client.commands.find(
          (c) => c.aliases && c.aliases.includes(args[0].toLowerCase())
        );

      if (!command) {
        const embed = new discord.MessageEmbed()
          .setTitle(text.getGuildLocale(message.channel.id,"HelpCommandInvalid"))
          .setColor("FF0000");
        return (await msg).edit(embed);
      }

      const COMMANDDETAILS = text.getGuildLocale(message.guild.id,"CommandInfo");
      let commandDetails = COMMANDDETAILS.split("::") 
      const embed = new discord.MessageEmbed()
        .setTitle(commandDetails[0])
        .addField(commandDetails[1], `\`${prefix}\``)
        .addField(
          commandDetails[2],
          command.name ? `\`${command.name}\`` : "Comando sem nome"
        )
        .addField(
          commandDetails[3],
          command.aliases
            ? `\`${command.aliases.join("` `")}\``
            : commandDetails[4]
        )
        .addField(
          commandDetails[5],
          command.usage
            ? `\`${prefix}${command.name} ${command.usage}\``
            : `\`${prefix}${command.name}\``
        )
        .addField(
          commandDetails[6],
          command.description
            ? command.description
            : commandDetails[7]
        )
        .setFooter(
          `${message.author.tag}`,
          message.author.displayAvatarURL({ dynamic: true })
        )
        .setTimestamp()
        .setColor(roleColor);
      return (await msg).edit(embed);
    }
  },
};
