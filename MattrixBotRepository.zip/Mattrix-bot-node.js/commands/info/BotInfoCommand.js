const discord = require("discord.js");
const config = require("../../config");
const emoji = require("../../Scripts/Utils/Bot_Emojis.js");
const os = require("os");
const cpuStat = require("cpu-stat")
module.exports = {
  name: "botinfo",
  description: "ve o uso do bot.",
  /**
   *
   * @param {discord.Client} client
   * @param {discord.Message} message
   * @param {String[]} args
   */
  run: async (client, message, args) => {
    const embed = new discord.MessageEmbed();
    embed.setTimestamp();
    embed.setTitle("BOT INFO");
    embed.setDescription(`${emoji.loading(client)}| Aguarde...`);
    embed.setColor(message.member.displayHexColor);
    embed.setFooter(message.member.displayName, message.author.avatarURL());
    let msg = await message.channel.send(embed);
    const shared_ram_usage = process.memoryUsage().external;
    //var pjson = require('../../package.json');

    //let v = pjson.dependencies['discord.js']
    //v = discordversion.replace()
    //discord.version
    let CpuUsage = process.cpuUsage().user;
    let devs = "";

    try{
    for (dev of config.dev) {
      devs += client.users.cache.find(user => user.id == dev).tag +" "
    }
  }
  catch {
    
  }
   /* const description = `
    DEVS -> ${devs}\n\
    :computer: **| Memoria RAM compartilhada**: ${Math.round(
      shared_ram_usage / 1e6
    )} MB\n:computer: **| Memoria Ram**:  MB\n:computer: **| CPU: ${
      os.cpus()[0].model
      }\n:computer: | CPU Usage: ${cpuUsage} \%**\n
    ${emoji.get_emoji(
      client,
      "bot_node_js_logo"
    )} **| Versão do Node.js: ${process.version}**\n${emoji.get_emoji(
      client,
      "bot_djs_logo"
      )} **| Versão do Discord.js: ${discord.version}**`;
    */
   
   embed.setDescription(`Olá,${message.author} aqui está!`)
    embed.addField(":computer: -> Uso de CPU\n%",`\`\`\`${CpuUsage /1e10}%\`\`\``,true)
    embed.addField(":computer: -> Uso de Memoria Ram",`\`\`\`${Math.round(process.memoryUsage().heapTotal / 1024 /1024)} mb \`\`\``,true);
    embed.addField(`${emoji.get_emoji(client,"bot_node_js_logo")} -> Versão do Node.js`,`\`\`\`${process.version}\`\`\``,true);
    embed.addField(`${emoji.get_emoji(client,"bot_djs_logo")} -> Versão do Discord.js`,`\`\`\`${discord.version}\`\`\``,true);
    embed.addField(":sunglasses: -> Devs", `\`\`\`${devs}\`\`\``,false);
    embed.addField(":book: -> Créditos","```fuzer#0421 Por Fazer as artes do Help e Botinfo!```",false)
    embed.addField(":computer: -> CPU",`\`\`\`${os.cpus()[0].model}\`\`\``,false)
    embed.setImage("https://cdn.discordapp.com/attachments/775678690750103565/810865618311315466/IMG_20210215_102903.png")
    //embed.setDescription(description);
    await msg.edit(embed);
  },
};
