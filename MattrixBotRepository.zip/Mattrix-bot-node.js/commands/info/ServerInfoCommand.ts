import discord = require("discord.js");
import String = require("../../Scripts/Utils/String")
module.exports = {
    name:"serverinfo",
    description:"Mostra as informações do servidor.",
    aliases:["informacõesdoservidor","infodosv"],
    run: async (client:discord.Client,message:discord.Message,args) =>
    {
        
        message.channel.startTyping();
        const UI = await UsersInfo(message.guild);
        const embed = new discord.MessageEmbed()
        embed.addField("Dono(a)",message.guild.owner.user.tag)
        embed.setTitle(`Informações de ${message.guild.name}`);
        if (message.guild.afkChannel){
            embed.addField("Canal AFK",message.guild.afkChannel)
        }
        if(message.guild.emojis)
        {
            embed.addField("Emojis",`\`${(await message.guild.emojis.cache.size)}\``)
        }
        embed.addField("ID",message.guild.id)
        embed.addField("Região", String.capitalize( message.guild.region))
        embed.addField("Total de Membros",`\`${message.guild.members.cache.size}\``,true);
        embed.addField("Membros Online",`\`${UI.UsersOnline}\``)
        embed.addField("Membros Offline",`\`${UI.UsersOffline}\``);
        embed.addField("Membros Ausentes", `\`${UI.UsersIDLE}\``);
        embed.addField("Membros DND",`\`${UI.UsersDND}\``);
        embed.addField("Membros no app PC",`\`${UI.UsersInDesktop}\``);
        embed.addField("Membros no Site do discord",`\`${UI.UsersInWebSite}\``);
        embed.addField("Membros no celular",`\`${UI.UsersInPhone}\``);
        embed.addField("Bots",`\`${UI.Bots}\``);
       
        message.channel.stopTyping()
        message.channel.send(embed)
    }
}
async function UsersInfo(Guild:discord.Guild)
{
    let UsersInPhone = 0;
    let UsersInDesktop = 0;
    let UsersInWebSite = 0;
    let UsersOFF = 0;
    let UsersON = 0;
    let UsersIDLE = 0;
    let UsersDND = 0;
    let UsersInvisible = 0;
    let Bots = 0;
  
    await(await Guild.members.fetch()).forEach(member => {
        
  
        const User = member.user;
       if(User)
       {
        if(User.bot)
          {
            Bots++;
           
          }
        const on = User.presence.clientStatus;
        if(on){
        if (on.web) {
           UsersInWebSite++;
          } else if (on.desktop) {
           UsersInDesktop++;
          } else if (on.mobile) {
           UsersInPhone++;
          }
        }
          
          let status = User.presence.status;
          switch (status) {
            case "dnd":
             UsersDND++;
              break;
            case "idle":
             UsersIDLE++;
              break;
            case "invisible":
             UsersInvisible++;
              break;
            case "offline":
             UsersOFF++;
              break;
            case "online":
             UsersON++;
              break;
            default:
              
              break;
          }
        }
    });
        
          const result = {
              UsersInDesktop: UsersInDesktop,
              UsersDND:UsersDND,
              UsersInPhone:UsersInPhone,
              UsersInWebSite: UsersInWebSite,
              UsersOffline:UsersOFF,
              UsersOnline:UsersON,
              UsersIDLE: UsersIDLE,
              UsersInvisible:UsersInvisible,
              Bots:Bots,
          }
          console.log(result)
          return result;
          
    }
