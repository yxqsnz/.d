import d = require("../../Scripts/Utils/DiscordUtils");
import discord = require('discord.js');
module.exports ={
    name:"uptime",
    description:"Get bot uptime",
    aliases:['on'],
    run: async(client:discord.Client,discord:discord.Message) =>{
        
    }
}