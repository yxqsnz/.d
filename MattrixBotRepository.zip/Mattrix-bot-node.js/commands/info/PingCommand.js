const discord = require("discord.js");
const Timer = require("time-counter");
const imgur = require("../../api/Imgur");
const { TenorClient } = require("../../api/Tenor");
const Emoji = require("../../Scripts/Utils/Bot_Emojis.js");
module.exports = {
  name: "ping",
  description: "Pegar a latência do bot",
  /**
   *
   * @param {discord.Client} client
   * @param {discord.Message} message
   * @param {*} args
   */
  run: async (client, message, args) => {
    
    let embed = new discord.MessageEmbed();
    embed.setFooter(message.member.displayName, message.author.avatarURL());
    embed.setTitle("Aguarde...");
    embed.setColor(message.member.displayHexColor);
    embed.setDescription(`${Emoji.loading2(client)} - ...`);
    let msg = await message.channel.send(embed);
    embed.setTitle("Ping!");
    let api_ping = client.ws.ping;
    let gate_way_ping = Math.floor(msg.createdAt - message.createdAt);
    const c = new Timer();
    c.start();
    await TenorClient.Search.Random("Discord", "1");
    c.stop();
    let tenor_ping = c.stoppedTime - c.timerStartTime;
    const f = new Timer();
    f.start();
    await imgur.search("Discord");
    f.stop();
    let Imgur_ping = f.stoppedTime - f.timerStartTime;
    embed.setDescription(
      `**BOT**\nGateway: ${gate_way_ping} MS\nAPI: ${api_ping} MS\n**External APIS**\nTenor: ${tenor_ping} MS\nImgur: ${Imgur_ping} MS`
    );
    await msg.edit(embed);
  },
};
