const discord = require('discord.js');
module.exports = {
    name:"lock",
    description:"Trava o canal",
    minPermissions:["MANAGE_CHANNELS"],
    minBotPermissions:["MANAGE_CHANNELS"],
    aliases:['lockchannel','travacanal'],
    /**
     * 
     * @param {discord.Client} Client 
     * @param {discord.Message} message 
     */
    run: async (Client,message,text)=>{
        const LockEmbed = new discord.MessageEmbed();
     
       (await message).channel.updateOverwrite(message.guild.roles.everyone,{ SEND_MESSAGES:false})
        LockEmbed.setTitle(text.getGuildLocale(message.guild.id,"LockSuccess")); 
        LockEmbed.setColor("RED");
 
        message.channel.send(LockEmbed)   
  }
}