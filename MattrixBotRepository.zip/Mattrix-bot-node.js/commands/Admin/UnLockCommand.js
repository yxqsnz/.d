const discord = require('discord.js');
module.exports = {
    name:"unlock",
    description:"Destrava o canal",
    minBotPermissions:["MANAGE_CHANNELS"],
    minPermissions:["MANAGE_CHANNELS"],
    aliases:['unlockchannel','destravarcanal'],
    /**
     * 
     * @param {discord.Client} Client 
     * @param {discord.Message} message 
     */
    run: async (Client,message,text)=>{
        const LockEmbed = new discord.MessageEmbed();
        LockEmbed.setColor("RED");
        
       (await message).channel.updateOverwrite(message.guild.roles.everyone,{ SEND_MESSAGES:true})
        LockEmbed.setColor("BLUE")
        LockEmbed.setTitle(text.getGuildLocale(message.guild.id,"UnLockSuccess")); 
        message.channel.send(LockEmbed)   
  }
}