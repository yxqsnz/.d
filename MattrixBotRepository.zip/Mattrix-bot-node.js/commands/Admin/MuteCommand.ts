import discord = require('discord.js');
import ms = require('ms')
import controller  = require("../../Controllers/MuteController");
import { setTimeout } from 'timers';
module.exports = {
    name:"mute",
    aliases:["tempmute","mutar"],
    minPermissions:["MANAGE_ROLES"],
    minBotPermissions:["MANAGE_ROLES","MANAGE_CHANNELS","MANAGE_MESSAGES"],
    run: async (client:discord.Client,message:discord.Message,args:String[],text) =>{
    
    const muteEmbed = new discord.MessageEmbed();
    let valid = false;
    const member = message.mentions.members.first();
    if(!member){
        muteEmbed.setColor("RED");
        muteEmbed.setTitle(text.getGuildLocale(message.guild.id,"MissingMemberMention"));
        message.reply(muteEmbed);
        return;
     }
    let pMutes;
    let cMute;
    if(member){
        pMutes = await controller.getPreviousMutes(member.id);
        cMute = pMutes.filter(mute => {
            return mute.current === true;
        })
        
    }
    let exp = Date.now() ;

    if(cMute.length){
        return message.reply(text.getGuildLocale(message.guild.id,"MuteUserAlreadyMuted"));
    }

    let mili = 0;
    const rfilter = (reaction, user) => {
        return  user.id === message.author.id;
    };
  
     if(member.hasPermission("ADMINISTRATOR")){
        message.reply(text.getGuildLocale(message.guild.id,"MuteFailedUserIsAModerator")); 
        return;
     }
     muteEmbed.setTitle("Mute");
     muteEmbed.setColor("RED");
     muteEmbed.setDescription(text.getGuildLocale(message.guild.id,"MuteTimeQuestion"));
     const msg = message.channel.send(muteEmbed);
     const filter = m => m.author.id === message.author.id
     const collector = message.channel.createMessageCollector(filter, { time: 15000 });
    
    collector.on('collect',async m => {
    if(m.content.toLowerCase() == "auto"){
        mili = pMutes.length * 6000 + 1;
    
    }else{
        mili = ms(m.content);

    }

    if(!mili){
        if (message.guild.me.hasPermission("MANAGE_MESSAGES")){
            try{
                m.delete();
            }
            catch(e){

            }
        }
        message.reply("Invalid!");
    }
    else{
        if (message.guild.me.hasPermission("MANAGE_MESSAGES")){
         try{
            m.delete();
         }
         catch(e){}
        }
        muteEmbed.setTitle("MUTE");

        muteEmbed.setDescription(text.getGuildLocale(message.guild.id,"MuteConfirmation",member.displayName,ms(mili, { long: true })));
        (await msg).edit(muteEmbed);
        (await msg).react("✅")
        valid = true;
        collector.stop();
        const rcollector = (await msg).createReactionCollector(rfilter, { time: 15000 });
        rcollector.on('collect', async (reaction, user) => {
            if(reaction.emoji.name == "✅")
            {
                rcollector.stop();
                exp = Date.now() 
                exp += mili;
                const nexp = new Date(exp)
                await controller.New(message.author.id,message.guild.id,member.id,nexp)
                if(!message.guild.roles.cache.find(r => r.name == "TH_MUTED")){
                await message.guild.roles.create({
                    data: {
                      name: 'TH_MUTED',
                      color: 'RED',
                      permissions:["VIEW_CHANNEL","SPEAK"]
                    },
                    
                    reason: 'Muted.',
                  }).catch((e) =>{

                      message.reply("An error has ocurred: " + e);
                      return;
                  })
               }
               
               const role = message.guild.roles.cache.find(r => r.name == "TH_MUTED");
    
                message.guild.channels.cache.array().filter(r => true).forEach(c =>  {
                c.updateOverwrite(role,{ SEND_MESSAGES:false})
                })
                
               
               member.roles.add(role);
             
               (await msg).delete();
              
               const t = text.getGuildLocale(message.guild.id,"MemberPunished",member.displayName,"Muted");
               const o = t.split("||");
               const punMessage = new discord.MessageEmbed();
               punMessage.setTitle(o[0]);
               punMessage.setDescription(o[1]);
               punMessage.setColor(member.displayHexColor)
               message.channel.send(punMessage);
              
        }
        });
        rcollector.on('end', collected => {
            if(!valid){
                muteEmbed.setTitle("Canceled.");
                muteEmbed.setDescription("");
                message.channel.send(muteEmbed);
            }
          });
    }
    collector.on('end', collected => {
       if(!valid){
           muteEmbed.setTitle("Canceled.");
           muteEmbed.setDescription("");
           message.channel.send(muteEmbed);
       }
     });

   

    });     
    
    }
}