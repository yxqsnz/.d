
const discord = require("discord.js");
const emoji = require("../../Scripts/Utils/Bot_Emojis");
const {sleep} = require("../../Scripts/Utils/Utils")
module.exports = {
  name: "clear",
  description: "limpa o chat",
  minPermissions:["MANAGE_MESSAGES"],
  minBotPermissions:["MANAGE_MESSAGES"],
  aliases: ["limpar", "prune"],
  /**
   *
   * @param {discord.Client} client
   * @param {discord.Message} message
   * @param {String[]} args
   */
  run: async (client, message, args,text) => {
    let messagesDeletedWithErrors = 0;
    let messagesDeleted = 0;
    if (args.length <= 0) {
      message.reply(text.getGuildLocale(message.guild.id,"ClearArgsNotValid",args[0]))
      return;
    }
   if(!parseInt(args[0])){
    message.reply(text.getGuildLocale(message.guild.id,"ClearArgsNotValid",args[0]))
   }
    
    
  
    const MESSAGESLENGTH = args[0]
    const embed = new discord.MessageEmbed();
    embed.setTitle(text.getGuildLocale(message.guild.id,"ClearFetchingMessages",emoji.loading(client)));
     await message.channel.send(embed);

    if(parseInt(args[0]) >= 100){
     while(messagesDeleted < MESSAGESLENGTH){
      messagesDeleted += 100;
     try{
      await message.channel.bulkDelete(100).catch(() =>{
        messagesDeletedWithErrors += 100;
      })}
      catch{
        messagesDeletedWithErrors += 100;
      }
       embed.setTitle(text.getGuildLocale(message.guild.id,"ClearProgress",messagesDeleted,MESSAGESLENGTH,emoji.loading(client)));
       message.channel.send(embed).then((m) =>{
         m.delete({timeout:200}).catch()
       })
     }
    }
    else{
      
      messagesDeleted = 100;
    }

  },
};
