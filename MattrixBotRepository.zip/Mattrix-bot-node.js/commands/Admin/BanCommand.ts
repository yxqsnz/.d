let memberBanned = false
import discord = require("discord.js");

const gifs = ["https://media.tenor.com/images/14cffe4182dbdac64fc615234d573a23/tenor.gif","https://media.tenor.com/images/251934048e46526db580b7026c3957f1/tenor.gif","https://media.tenor.com/images/2c5ca0873795c0bcf82cbc92075dbed3/tenor.gif","https://media.tenor.com/images/2cc3d730b7b2f0ae68f39e7724232cff/tenor.gif"]
module.exports = {
    name:"ban",
    aliases:['banir'],
    minPermissions:["BAN_MEMBERS"],
    minBotPermissions:['BAN_MEMBERS'],
    description:"Banir um membro",
    run: async (client:discord.Client,message:discord.Message,args:String[],text) =>{
        const m = message.channel.send("** **");
        const embed = new discord.MessageEmbed()
        embed.setColor("RED");
        
        const member = message.mentions.members.first();
        if(member == message.member){
            embed.setTitle(text.getGuildLocale(message.guild.id,"BanYourselfError"));
            (await m).edit(embed);
            return;
        }
        if(!member){
            embed.setTitle(text.getGuildLocale(message.guild.id,"MissingMemberMention"));
            (await m).edit(embed);
            return;
        }
        args[0] = ""
       let reason = args.join(" ");
        
        if(reason == "" || reason == " ")
        {
            embed.setTitle(text.getGuildLocale(message.guild.id,"BanMissingReason"));
            (await m).edit(embed);
            return;
        }
        if(!member.bannable){
            embed.setTitle((text.getGuildLocale(message.guild.id,"UnableToBan",member.user.tag)));
            (await m).edit(embed);
            return;
        }
        embed.setTitle("Ban")
        embed.setThumbnail("https://cdn.discordapp.com/emojis/741379495453392927.gif");
        embed.setTimestamp();
        embed.setFooter(message.author.tag,message.author.displayAvatarURL());
        embed.setDescription(text.getGuildLocale(message.guild.id,"BanConfirmation",member.user.username,reason));
        (await m).edit(embed);
        (await m).react("✅");
        const filter = (reaction, user) => {
            return user.id == message.author.id
        }
        const coletor =  (await m).createReactionCollector(filter, {time: 30000})
        coletor.on("collect", async reaction =>{
            if(reaction.emoji.name == "✅"){
                const userEmbed = new discord.MessageEmbed();
                const banMessage = text.getGuildLocale(message.guild.id,"BanUserMessage",message.guild.name,message.author.tag,reason)
                userEmbed.setColor("RED")
                userEmbed.setTitle(banMessage.split("||")[0]);
                userEmbed.setDescription(banMessage.split("||")[1]);
                await member.send(userEmbed).catch();
                
               
                if(message.guild.me.hasPermission("MANAGE_MESSAGES")){
                    (await m).reactions.removeAll()
                }
                await member.ban({reason:reason})
                memberBanned = true;
                const PunishmentMessage = text.getGuildLocale(message.guild.id,"MemberPunished",member.user.tag,banMessage.split("||")[2]);
                const gif = gifs[Math.round(Math.random() * gifs.length)];
                
                embed.setTitle(PunishmentMessage.split("||")[0]);
                embed.setDescription(PunishmentMessage.split("||")[1]);
                if(banMessage.split("||")[2] == " BANIDO") {
                    embed.setImage(gif)
                }
                (await m).edit(embed);
                coletor.emit("end");
                coletor.stop();
            }
        })
        coletor.on("end",async ()=>{
            if(!memberBanned) (await m).delete();
        })
    }
}