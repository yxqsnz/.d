import discord = require("discord.js")
module.exports ={
    name:"sayasme",
    description:"um say soq com vc",
    aliases:["sam","say as me"],
    usage:"[#canal] <msg>",
    run: async (discord:discord.Client,message:discord.Message,args:String[]) =>{
        if(!message.member.hasPermission("MANAGE_MESSAGES"))
        {
            message.reply("você não tem permissão de `Gerenciar mensagens` Para usar o comando.")
            return
        }
        if(!message.guild.me.hasPermission("MANAGE_WEBHOOKS"))
        {
            message.reply("Desculpe Eu não tenho permissão de `Gerenciar Webhook` para usar o commando.")
            return
        }
        let channel = message.mentions.channels.first();
        let ThisChannel = message.channel;
        let selectedCh;
        if(!channel)
        {
          selectedCh = ThisChannel;
        }
        else{
            selectedCh = channel;
        }
        const member = message.guild.member(message.mentions.users.first())
        let wb =  selectedCh.createWebhook(message.author.username,{avatar: message.author.displayAvatarURL()});
        if(member){
            wb = selectedCh.createWebhook(member.user.username, {avatar: member.user.displayAvatarURL()})
        }
        let mb = ""
        if(member){

            mb = member.toString()
        }
        
        
        let text = args.join(" ");
        text = text.replace(selectedCh,"");
        
        text = text.replace(mb, "")
        
        
        if(!text){
            text = "**Leave me alone**"
        }
        (await wb).send(text);
        async function delWb(){
            (await wb).delete()
        }
        setTimeout(() => {
            delWb()
        }, 1000 * 10);
       
        
    }
}