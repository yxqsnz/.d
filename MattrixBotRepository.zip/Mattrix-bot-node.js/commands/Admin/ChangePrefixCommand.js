const { Message, Client } = require("discord.js");
const database = require('../../Scripts/Utils/database')
const o = require("../../Controllers/ConfigController")
const dp = require("discord-prefix");
module.exports = {
  name: "prefix",
  description: "muda o prefixo do servidor",
  category: "Admin",
  minPermissions:["ADMINISTRATOR"],
  /**
   * @param {Client} client
   * @param {Message} message
   * @param {String[]} args
   */
  run: async (client, message, args,text) => {
    const i = o.LoadSettings(message.guild.id);
      if(!args.length){
        message.channel.send(`\`${i.prefix}\´`);
        return;
      }
      args = args.join(" ");
      i.prefix = args;
      const cfg = database.Client.db("Guild").collection("Config");
      await cfg.updateOne(
        {
          guildID : message.guild.id
        },
        {
          $set: { prefix: String(args)},
        }
      );
      await o.SaveSettings(message.guild.id,i);
      await message.channel.send(text.getGuildLocale(message.guild.id,"PrefixChangedSuccess",args));
  
      
    
  },
};
