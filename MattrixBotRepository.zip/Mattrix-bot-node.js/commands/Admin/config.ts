import Locale = require('../../Controllers/LanguageController');
import config = require('../../Controllers/ConfigController')
import discord = require('discord.js');
import l = require("../../Controllers/LanguageController")
import SubCommand = require('../../Scripts/handler/RunSubCommand');
module.exports ={
    name:"config",
    description:"Configure the bot",
    run: async (client:discord.Client,message:discord.Message,args:string[])  =>{
		
        const settings = await config.LoadSettings(message.guild.id)
        if(!settings){
            await config.NewSettings(message.guild.id);
        }
        switch (args[0]){
            case 'anti-spam':
                SubCommand.Run(args[0],client,message,args);
                break;
            case 'language':
                SubCommand.Run(args[0],client,message,args);
                break;
            case 'commandNotFound':
                SubCommand.Run(args[0],client,message,args);
                break
            default:
                message.reply(await l.getGuildLocale(message.guild.id,"MissingRequiredArgument","Setting"))
        }
        
       
            
        
    }
}
