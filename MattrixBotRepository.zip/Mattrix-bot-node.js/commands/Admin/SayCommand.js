const discord = require("discord.js");
module.exports = {
  name: "say",
  aliases: ["falar"],
  description: "Faz o bot falar algo",
  /**
   *
   * @param {discord.Client} client
   * @param {discord.Message} message
   * @param {String[]} args
   */
  run: async (client, message, args) => {
    let channel = message.mentions.channels.first();
    if (!channel) {
      channel = message.channel;
    }
    if (!message.member.hasPermission("MANAGE_MESSAGES")) {
      await message.reply(
        "Você não tem permissão.\nVocê precisa da permissão `Gerenciar mensagens` para executar esse comando!."
      );
      return;
    }

    args = args.join(" ");
    args = args.toString().replace(channel, "");
    if (args.length <= 0) {
      args = "Mensagem não especificada.";
    }
    let text = `${args}\n-> ${message.author}`; 
    channel.send(text);
  },
};
