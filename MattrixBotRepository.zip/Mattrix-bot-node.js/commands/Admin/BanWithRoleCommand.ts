import * as discord from 'discord.js'
import * as database from '../../Scripts/Utils/database'
let usersBanned = 0;
let usersBannedWithError = 0 ;
let description = "";
import * as emoji from '../../Scripts/Utils/Bot_emojis_ts'
    module.exports = {
    name : 'banwithrole',
    aliases : ['bwr', 'bancomcargo'],
    usage : "@cargo",
    minPermissions:["BAN_MEMBERS"],
    minBotPermissions:["BAN_MEMBERS"],
    description : "banir todo mundo com um cargo mencionado",
    run : async(client:discord.Client, msg: discord.Message, args:string[],TEXT) => {
        
        const embed = new discord.MessageEmbed(); 
        embed.setColor("RED");
        embed.setFooter(TEXT.getGuildLocale(msg.guild.id,"BWRFooter"));
        embed.setTitle("E");
        const m = await msg.channel.send(embed)
        const role = msg.mentions.roles.first()
        if(!role){
            embed.setTitle(TEXT.getGuildLocale(msg.guild.id,"MissingRoleMention"));
            return m.edit(embed)
        }else{
            embed.setTitle(TEXT.getGuildLocale(msg.guild.id,"SearchingForUsersWithThisRole",role.name))
            m.edit(embed);
        }
        
       
       

        /**
         * pegar cargos
         */
        msg.guild.members.fetch();
        let usersInGuild =  (await msg.guild.members.fetch()).array();


    
       
        let usersWithRole = 0
        let usersGetted = []
        for(let i = 0; i < usersInGuild.length; i++){
            if(usersInGuild[i].roles.cache.find(r => r.id == role.id)){
                usersGetted.push(usersInGuild[i].user.id)
                usersWithRole++
            }
        }
        const emojiReact = [ '✅','❌' ]
        const filter = (reaction, user) => {
            return reaction.emoji.name == emojiReact[0] || reaction.emoji.name == emojiReact[1]
        }
        if(!usersGetted.length || usersGetted.length <= 0){
            embed.setTitle(TEXT.getGuildLocale(msg.guild.id,"BWRERROR"));
            return await m.edit(embed);
        }
        async function usernames(){
            let returnString = ""
            for(let i = 0; i < usersGetted.length; i++){
                returnString += ` ${client.users.cache.get(usersGetted[i]).username}\n`
                if(returnString.length > 1500){
                    break
                }
                if(!returnString || returnString == "" || returnString == " "){
                    embed.setTitle(TEXT.getGuildLocale(msg.guild.id,"BWRERROR"));
                    return await m.edit(embed);
                }
            }
            return returnString
        }
        if(usersWithRole <= 0 && !usersWithRole){
            usersWithRole = 0;
        }
        if(usersWithRole == 0){
            embed.setTitle(TEXT.getGuildLocale(msg.guild.id,"BWRERROR"));
            await m.edit(embed);
        }
        embed.setTitle(TEXT.getGuildLocale(msg.guild.id,"BWRConfirmation"))
        embed.setDescription(await usernames());

        async function banAll(){
           
            async function ban(whoban:number){
                if(msg.guild.me.hasPermission("MANAGE_MESSAGES")){
                    await msg.reactions.removeAll();
                    
                }
                embed.setTitle(`${await emoji.loading(client)}`)
                let user = msg.guild.members.cache.find(mb => mb.id == usersGetted[whoban])
                if(user){
                    if(user.bannable){
                        user.ban()
                        description += `${user.user.username} - OK\n`;
                        embed.setDescription(description);
                        m.edit(embed)
                        usersBanned++;
                        await setTimeout(async () => {
                            return false
                        }, 2500);
                    }else{
                        description += `${user.user.username} - ERR!\n`;
                        embed.setDescription(description);
                        m.edit(embed)
                        usersBannedWithError++;
                        await setTimeout(async () => {
                            return false
                        }, 2500);
                    }
                }

            }
            for(let i = 0; i < usersGetted.length; i++){
                let user = msg.guild.members.cache.find(mb => mb.id == usersGetted[i])
                if(user){
                    await ban(i)
                }
            }
            
            if(usersBannedWithError >= 1 && usersBanned >= 1)
            {
                embed.setTitle(TEXT.getGuildLocale(msg.guild.id,"BWRUsersBannedWithErrors",await emoji.ok(client),await emoji.error(client),usersBanned,usersBannedWithError))
                m.edit(embed)
            }
            else if(usersBanned == 0 && usersBannedWithError >= 1 ){
                embed.setTitle(TEXT.getGuildLocale(msg.guild.id,"BWRFailedToBan",await emoji.error(client)));
                m.edit(embed)
            }
            else if(usersBannedWithError == 0 && usersBanned >= 1){
                embed.setTitle(TEXT.getGuildLocale(msg.guild.id,"BWRAllUserBanned",await emoji.ok(client)));
                m.edit(embed)
            }
        }
        m.edit(embed)
        m.react(emojiReact[0])
        const coletor =  m.createReactionCollector(filter, {time: 30000})
        coletor.on('collect', (reaction, user) => {
            if(user.id == msg.author.id){
                switch(reaction.emoji.name){
                    case emojiReact[0]:
                        banAll()
                        coletor.stop()
                        break;
                }
            }
        })
    }

}
