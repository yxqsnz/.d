const discord = require("discord.js");
const { TenorClient } = require("../../api/Tenor");
module.exports = {
  name: "slap",
  description: "da um tapa em alguém",
  aliases: ["tapa"],
  /**
   *
   * @param {discord.Client} client
   * @param {discord.Message} message
   * @param {String[]} args
   */
  run: async (client, message, args) => {
    let user = message.mentions.users.first();
    if (!user) {
      await message.reply("Uso: slap @Membro");
      return;
    }
    let embed = new discord.MessageEmbed();

    embed.setTitle("Será que vi um tapa?");
    embed.setDescription(`${message.author} deu um tapa em ${user}`);
    embed.setColor("RED");
    embed.setThumbnail(user.avatarURL());
    embed.setFooter(
      message.author.username + " | Powered By Tenor",
      message.author.avatarURL()
    );
    TenorClient.Search.Random("anime slap", "1")
      .then((Results) => {
        Results.forEach((Post) => {
          let media = Post.media[0];

          embed.setImage(String(media.gif.url));
          message.channel.send(embed);
        });
      })
      .catch();
  },
};
