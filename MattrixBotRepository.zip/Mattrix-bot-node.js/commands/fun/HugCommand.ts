const discord = require("discord.js");
import nekosAPI = require('nekos.life')
const NekosClient = new nekosAPI


module.exports = {
  name: "hug",
  description: "da um abraço  em alguém",
  aliases: ["abraco"],
  usage: "[@Membro]",
  /**
   *
   * @param {discord.Client} client
   * @param {discord.Message} message
   * @param {String[]} args
   */
  run: async (client, message, args) => {
    let user = message.mentions.users.first();
    if (!user) {
      await message.reply("Uso: hug @Membro");
      return;
    }
    let embed = new discord.MessageEmbed();

    embed.setTitle("Abraço");
    embed.setDescription(
      `${message.author.username} Abraçou  ${user.username}`
    );
    embed.setColor("BLUE");
    embed.setThumbnail(user.avatarURL());
    embed.setFooter(
      message.author.username + " | Powered By Nekos.Life",
      message.author.avatarURL()
    );
  
    
      embed.setImage(await (await NekosClient.sfw.hug()).url);
      message.channel.send(embed);
  },
};
