import * as discord from 'discord.js'
 module.exports = {
    name : 'jogo-da-velha',
    aliases : ['velha', 'ttt'],
    run : async(client:discord.Client, msg: discord.Message, args:string[]) => {
        let vez = false
        const member = msg.guild.member(msg.mentions.users.first())
        if(!member){
            msg.channel.send("Você precisa marcar um usuario")
            return;
        }
        if(member.user.id === msg.author.id){
            msg.channel.send("Você nao pode se marcar :rolling_eyes:")
            return
        }
        if(member.user.bot){
            msg.channel.send("Você não pode jogar com um bot! :rolling_eyes:")
            return
        }
        const authorEmoji = "❌"
        const memberEmoji = "🔵"
        let emojis = []
        emojis[0] = "1️⃣"
        emojis[1] = "2️⃣"
        emojis[2] = '3️⃣'
        emojis[3] = '4️⃣'
        emojis[4] = '5️⃣'
        emojis[5] = '6️⃣'
        emojis[6] = '7️⃣'
        emojis[7] = '8️⃣'
        emojis[8] = '9️⃣'
        const malha = ["⬜","⬜","⬜","⬜","⬜","⬜","⬜","⬜","⬜"]
        
        
        
        const embed = new discord.MessageEmbed
        embed.setTitle(`vez de ${msg.author.username}`)
        embed.addFields({
            name: "Campo", value: `${malha[0]}${malha[1]}${malha[2]}\n${malha[3]}${malha[4]}${malha[5]}\n${malha[6]}${malha[7]}${malha[8]}`, inline: true
        })
        const filter = (reaction, user) => {
            return user.id == msg.author.id || user.id == member.user.id
        };
        const jogo = await msg.channel.send(embed)
        for(let i = 0; i < emojis.length; i++){
            jogo.react(emojis[i])
        }
        
        let hasWinner  = false
        function defineWinner(currentEmoji){
            if(malha[0] == currentEmoji && malha[1] == currentEmoji && malha[2] == currentEmoji){
                hasWinner = true
                let vencedor = msg.author.username
                if(!vez){
                    vencedor = member.user.username
                }
                embed.addField('Vencedor: ', vencedor)
                jogo.edit(embed)
                return
            }
            if(malha[0] == currentEmoji && malha[4] == currentEmoji && malha[8] == currentEmoji){
                hasWinner = true
                let vencedor = msg.author.username
                if(!vez){
                    vencedor = member.user.username
                }
                embed.addField('Vencedor: ', vencedor)
                jogo.edit(embed)
                return
            }
            if(malha[0] == currentEmoji && malha[3] == currentEmoji && malha[6] == currentEmoji){
                hasWinner = true
                let vencedor = msg.author.username
                if(!vez){
                    vencedor = member.user.username
                }
                embed.addField('Vencedor: ', vencedor)
                jogo.edit(embed)
                return
            }
            if(malha[1] == currentEmoji && malha[4] == currentEmoji && malha[7] == currentEmoji){
                hasWinner = true
                let vencedor = msg.author.username
                if(!vez){
                    vencedor = member.user.username
                }
                embed.addField('Vencedor: ', vencedor)
                jogo.edit(embed)
                return
            }
            if(malha[2] == currentEmoji && malha[4] == currentEmoji && malha[6] == currentEmoji){
                hasWinner = true
                let vencedor = msg.author.username
                if(!vez){
                    vencedor = member.user.username
                }
                embed.addField('Vencedor: ', vencedor)
                jogo.edit(embed)
                return
            }
            if(malha[2] == currentEmoji && malha[5] == currentEmoji && malha[8] == currentEmoji){
                hasWinner = true
                let vencedor = msg.author.username
                if(!vez){
                    vencedor = member.user.username
                }
                embed.addField('Vencedor: ', vencedor)
                jogo.edit(embed)
                return
            }
            if(malha[6] == currentEmoji && malha[7] == currentEmoji && malha[8] == currentEmoji){
                hasWinner = true
                let vencedor = msg.author.username
                if(!vez){
                    vencedor = member.user.username
                }
                embed.addField('Vencedor: ', vencedor)
                jogo.edit(embed)
                return
            }
        }
        function edit(){
            embed.fields = []
            embed.addFields({
                name: "Campo", value: `${malha[0]}${malha[1]}${malha[2]}\n${malha[3]}${malha[4]}${malha[5]}\n${malha[6]}${malha[7]}${malha[8]}`, inline: true
            })
            let username = msg.author.username
            if(vez){
                username = member.user.username
            }
            embed.setTitle(`vez de ${username}`)
            jogo.edit(embed)
        }
        async function removeReaction(reaction)
        {
            if (msg.guild.me.hasPermission("MANAGE_MESSAGES")) {
                jogo.reactions.cache.get(reaction).remove()
              }
        }
        const coletor = jogo.createReactionCollector(filter, {time: 1000 * 60 * 15})
        coletor.on('collect', (reaction, user) => {
            if(hasWinner){
                coletor.stop()
                return
            }
            if(vez == false && user.id == msg.author.id){
                for(let i = 0; i < emojis.length; i++){
                    if(reaction.emoji.name == emojis[i]){
                        if(malha[i] == "⬜"){
                            malha[i] = authorEmoji
                            vez = true
                            edit()
                            removeReaction(reaction.emoji.name)
                            defineWinner(authorEmoji)
                        }
                    }
                }
            }
            if(vez == true && user.id == member.user.id){
                for(let i = 0; i < emojis.length; i++){
                    if(reaction.emoji.name == emojis[i]){
                        if(malha[i] == "⬜"){
                            malha[i] = memberEmoji
                            vez = false
                            edit()
                            defineWinner(memberEmoji)
                            removeReaction(reaction.emoji.name)
                        }
                    }
                }
            }
        })
    }

}