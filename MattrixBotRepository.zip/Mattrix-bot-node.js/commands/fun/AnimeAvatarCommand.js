const  discord = require("discord.js");
const NekosClient  = require("../../api/Nekos.Life")
module.exports = {
    
    name:"animeavatar",
    description:"Procura um avatar no Nekos.Life!",
    /**
     * 
     * @param {discord.Client} client 
     * @param {discord.Message} message 
     */
    run: async (client,message) =>{
        message.channel.startTyping();
       const embed = new discord.MessageEmbed();
       embed.setTitle("Aqui está!");
       embed.setTimestamp()
       embed.setFooter(message.author.username + "| Powered By Nekos.Life",message.author.displayAvatarURL());

       if(message.channel.nsfw)
        {
            embed.setColor("RED")
            embed.setImage(await (await NekosClient.nsfw.avatar()).url);
            message.channel.send(embed)
        }
        else{
            embed.setColor("BLUE")
            embed.setImage((await NekosClient.sfw.avatar()).url);
            message.channel.send(embed);
        }
        message.channel.stopTyping()
    }
}