import * as discord from 'discord.js'
import * as database from '../../Scripts/Utils/database'
import * as emoji from '../../Scripts/Utils/Bot_emojis_ts'
    module.exports = {
    name : 'emoji',
    aliases : ['guild-emoji', 'gemoji'],
    usage : "<emoji name> (opcional => --global) (opcional => --all)",
    run : async(client:discord.Client, message: discord.Message, args:string[],text) => {
        const embed = new discord.MessageEmbed
        embed.setTitle(`${await emoji.FindEmojiByName(client, "bot_loading")}`)
        const m = await message.channel.send(embed)
        //vai caraio


            const eml = client.emojis.cache.array()
            async function pag(i:number){

                if(!eml[i]) return
                embed.setTitle(text.getGuildLocale(message.guild.id,"ClickToDownload"))
                embed.setURL(eml[i].url)
                embed.setImage(eml[i].url)
                embed.fields = []
                embed.addField("Server", eml[i].guild.name)
                embed.addField("POS", `${i+1} / ${eml.length}`)
                embed.addField('Emoji', `${eml[i].name}`)
                m.edit(embed)
                    //bot crasho preciso ver o pq
            }
        
        if(!args[0]){
            embed.setTitle(`${await emoji.FindEmojiByName(client, "bot_error")} - ${text.getGuildLocale(message.guild.id,"EmojiMissingName")}`)
            return m.edit(embed)
        }
        async function removeReaction(reaction, id){
            await m.reactions.cache.get(reaction).users.remove(id)
        }
        if(args[0] == "-all" || args[0] == "-a"){
            const ES = ['➡️', '⬅️']
            const emj = client.emojis.cache.array()
            let pagn = 0
            const valor = parseInt(args[1])
            if(!isNaN(valor)){

                pagn = valor -1
                if(pagn > emj.length || pagn < 0){
                    pagn = 0
                }

            }
            
            pag(pagn)
            const filter = (reaction, user) => {
                return reaction.emoji.name == ES[0] || reaction.emoji.name == ES[1]
            }
            m.react(ES[1])
            m.react(ES[0])
            
            const coletor = m.createReactionCollector(filter, {time: 1000 * 60 * 10})
            coletor.on('collect', (reaction, user) => {
                if(user.id == message.author.id){
                    switch(reaction.emoji.name){
                        case ES[0]:
                            if(emj[pagn+1]){
                                pagn += 1
                            }
                            if (message.guild.me.hasPermission("MANAGE_MESSAGES")) {
                                removeReaction(reaction.emoji.name, user.id)    
                            }
                            pag(pagn)
                            break
                        case ES[1]:
                            if(emj[pagn-1]){
                                pagn -= 1
                            }
                            if (message.guild.me.hasPermission("MANAGE_MESSAGES")) {
                                removeReaction(reaction.emoji.name, user.id)    
                            }
                            pag(pagn)
                            break
                    }
                }
            })
            

        }
        if(args[1]){
            if(args[1] == "-g" || args[1] == "--global"){
                const emj = await client.emojis.cache.find(e => e.name == args[0])
                if(!emj){
                    embed.setTitle(`${await emoji.FindEmojiByName(client, "bot_error")} - ${text.getGuildLocale("EmojiNotFound")}`)
                    return m.edit(embed)
                }
                embed.setTitle(`${await emoji.FindEmojiByName(client, "bot_ok")} - ${text.getGuildLocale(message.guild.id,"ClickToDownload")}`)
                embed.setURL(emj.url)
                embed.setImage(emj.url)
                return m.edit(embed)
            }
        }
        const emj = await message.guild.emojis.cache.find(e => e.name == args[0])
        if(!emj){
            if(args[0] != "-a"){
                if(args[0] != "-all"){

                    embed.setTitle(`${await emoji.FindEmojiByName(client, "bot_error")} - ${text.getGuildLocale(message.guild.id,"EmojiNotFound2")}`)
                    return m.edit(embed)
                }
            }
        }
        if(args[0] != "-a"){
            if(args[0] != "-all"){

                embed.setTitle(`${await emoji.FindEmojiByName(client, "bot_ok")} - ${text.getGuildLocale(message.guild.id,"ClickToDownload")}`)
                embed.setURL(emj.url)
                embed.setImage(emj.url)
                m.edit(embed)
            }
        }
        
    }

}
