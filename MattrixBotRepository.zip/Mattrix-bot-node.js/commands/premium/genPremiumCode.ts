import * as discord from 'discord.js'
import * as database from '../../Scripts/Utils/database'
import * as emoji from '../../Scripts/Utils/Bot_emojis_ts'
    module.exports = {
    name : 'genPremiumCode',
    aliases : ['gpc'],
    run : async(client:discord.Client, msg: discord.Message, args:string[]) => {
        const codeLength = 7
        async function genCode(){

            const puta  = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890"
            let code = ""
            
            
            for(let i = 0; i < codeLength; i++){
                let i = Math.floor(Math.random() * puta.length)
                code += puta[i]
            }
            const PremiumCodes = database.Client.db('premium')
            const pc = PremiumCodes.collection('codes')
            const cFind = pc.findOne({code: code})
            if(cFind){
                pc.deleteOne(
                    {code: code}
                )
            }
            return code
        }
            
        
        async function insert(iNeedTheCode:string){
            const PremiumCodes = database.Client.db('premium')
            const pc = PremiumCodes.collection('codes')
            const codeSpecs ={
                "code": iNeedTheCode,
                "author": msg.author.id
            }
            await pc.insertOne(codeSpecs)
        }
        if(msg.author.id == '567853754825572352' || msg.author.id == '450812271451439124') {


            const embed = new discord.MessageEmbed()
            embed.setTitle(`gerando codigo ${await emoji.loading(client)} `)
            const m = await msg.channel.send(embed)
            let code = await genCode()
            await insert(code)
            embed.setTitle(`${await emoji.ok(client)} PRONTO\nCodigo: ${code}`)
            m.edit(embed)
        }
        else{
            return msg.reply('apenas administradores do bot podem executar este comando!')
        }
    }

}
