const discord = require("discord.js");
const { stat } = require("fs");
const moment = require("moment");
const { userInfo } = require("os");
module.exports = {
  name: "userinfo",
  description: "Pega as info de algum usuário",
  usage: "[@member]",
  /**
   *
   * @param {discord.Client} client
   * @param {discord.Message} message
   * @param {String[]} args
   */
  run: async (client, message, args) => {
    let Member = message.mentions.members.first();
    let User = message.mentions.users.first();
    if (!Member) {
      Member = message.member;
      User = message.author;
    }
    if(!User){
      User = message.author;
    }
    const UserInfoEmbed = new discord.MessageEmbed();
    UserInfoEmbed.setAuthor(
      message.author.username,
      message.author.avatarURL()
    );
    UserInfoEmbed.setColor(Member.displayHexColor);
    UserInfoEmbed.addField(
      "Conta Criada em",
      moment(User.createdAt).format("DD/MM/YYYY [às] HH:mm")
    );
    if (Member.premiumSince) {
      UserInfoEmbed.addField(
        "Booster em",
        moment(Member.premiumSince).format("DD/MM/YYYY [às] HH:mm")
      );
    }
    UserInfoEmbed.setThumbnail(User.displayAvatarURL());
    UserInfoEmbed.setFooter(
      `Informações de ${User.tag}`,
      User.displayAvatarURL()
    );
    UserInfoEmbed.addField(
      "Entrou em",
      moment(Member.joinedAt).format("DD/MM/YYYY [às] HH:mm")
    );
    let pl = Member.presence.activities;
    pl = pl.join(" ");
    if (pl == "Custom Status") {
      pl = "Nada...";
    } else if (!pl) {
      pl = "**Nada...**";
    }
    let status = User.presence.status;
    switch (status) {
      case "dnd":
        status = "**Não perturbe**";
        break;
      case "idle":
        status = "**Ausente**";
        break;
      case "invisible":
        status = "**Invisível**";
        break;
      case "offline":
        status = "**Offline**";
        break;
      case "online":
        status = "**Online**";
        break;
      default:
        status = "**Leave me alone**";
        break;
    }
    let user_in = "";
    const on = User.presence.clientStatus;
    if(on){

    
    if (on.web) {
      user_in = "**No Site do discord**";
    } else if (on.desktop) {
      user_in = "**No Aplicativo do discord no PC**";
    } else if (on.mobile) {
      user_in = "**No Celular**";
    }
  }else{
    user_in = "**O usuário está offline.**";
  }
    const msg = await message.channel.send("** **");
    UserInfoEmbed.addField("Jogando", pl);
    UserInfoEmbed.addField("Status", status);
    UserInfoEmbed.addField("Está no", user_in);
    UserInfoEmbed.addField("Cargos", Member.roles.cache.array().length - 1);

    msg.react("▶️");

    const filter = (reaction, user) => {
      return user.id === message.author.id;
    };
    UserInfoEmbed.setColor(Member.displayHexColor);
    msg.edit(UserInfoEmbed);

    const collector = msg.createReactionCollector(filter, { time: 30000 });
    collector.on("collect", (reaction, user) => {
      if (reaction.emoji.name == "▶️") {
        if (message.guild.me.hasPermission("MANAGE_MESSAGES")) {
          msg.reactions.removeAll().catch();
        }

        const RolesAndPermsEmbed = new discord.MessageEmbed();
        RolesAndPermsEmbed.setTitle(
          "Cargos e Permissões de " + Member.displayName
        );
        let roles = "";
        for (let role of Member.roles.cache.array()) {
          roles += `\`${role.name}\`\n`;
        }
        if (roles.length >= 1024) {
          roles = roles.substring(0, 1024);
        }
        RolesAndPermsEmbed.setDescription(
          `**CARGOS**\n${roles}**PERMISSÕES**\n${Member.permissions.toArray()}`
        );
        RolesAndPermsEmbed.setColor(Member.displayHexColor);
        RolesAndPermsEmbed.setThumbnail(User.displayAvatarURL());
        RolesAndPermsEmbed.setFooter(
          `Informações de ${User.tag}`,
          User.displayAvatarURL()
        );
        msg.edit(RolesAndPermsEmbed);
        msg.react("◀️");
      }
      if (reaction.emoji.name == "◀️") {
        if (message.guild.me.hasPermission("MANAGE_MESSAGES")) {
          msg.reactions.removeAll().catch();
        }
        msg.edit(UserInfoEmbed);
        msg.react("▶️");
      }
    });
    collector.on("end", (collected) => {
      msg.delete();
    });
  },
};
