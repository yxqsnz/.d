const discord = require("discord.js");
module.exports = {
  name: "userroles",
  aliases: ["cargos"],
  description: "Cargos de um usuário",
  /**
   *
   * @param {discord.Client} client
   * @param {discord.Message} message
   * @param {String[]} args
   */
  run: async (client, message, args) => {
    let member = message.mentions.members.first();
    if (!member) {
      member = message.member;
    }

    let embed = new discord.MessageEmbed();
    embed.setTitle(`Cargos de ${member.user.username}`);
    let roles = "";
    if (member.displayHexColor) {
      embed.setColor(member.displayHexColor);
    } else {
      embed.setColor("C0C0C0");
    }

    for (let role in member.roles.cache.array()) {
      roles += `**${member.roles.cache.array()[role]}**\n`;
    }
    if (roles.length >= 2000) {
      roles = roles.substring(0, 1900);
      roles += "...";
    }

    if (roles.length <= 0 || roles == "") {
      roles = `o Membro ${member} não tem cargos.`;
    }
    embed.setDescription(roles);
    embed.setFooter(message.author.username, message.author.avatarURL());
    await message.channel.send(embed);
  },
};
