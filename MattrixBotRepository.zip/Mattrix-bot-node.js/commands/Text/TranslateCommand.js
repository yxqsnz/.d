const discord = require("discord.js");
const { translate } = require("../../Scripts/Utils/String")
const { loading } = require("../../Scripts/Utils/Bot_Emojis");
module.exports = {
  name: "translate",
  aliases: ["traduzir", "tdz"],
  usage: "<prefixo>[translate/tdz/traduzir] <para> <texto>",
  /**
   * @param {discord.Message} ctx
   * @param {discord.Client} client
   * @param {String[]} args
   */
  run: async (client, ctx, args, text) => {

    const language_to_translate = args[0];
    args[0] = "";
    const to_translate = args.join(" ");
    if (!args.length) {
      ctx.reply(text.getGuildLocale(message.guild.id, "MissingRequiredArgument", "LANGUAGE || TEXT "));
      return;
    }
    const embed = new discord.MessageEmbed();
    embed.setColor(ctx.member.displayHexColor);
    embed.setTitle(`${loading(client)} - ...`);
    const m = await ctx.channel.send(embed);

    try {
      const translated_text = await translate(to_translate, language_to_translate);

      embed.setTitle("Translate");
      embed.addField(text.getGuildLocale(ctx.guild.id, "Output"), `\`\`\`${translated_text}\`\`\` `, false);
      embed.setFooter(ctx.member.displayName, ctx.author.avatarURL());
      m.edit(embed);
    } catch (e) {
      const ei = text.getGuildLocale(ctx.guild.id, "TranslateError");
      const o = ei.split("::")
      embed.setTitle(o[0]);
      embed.setDescription(
        o[1]
      );
      m.edit(embed);
      return;
    }
  },
};
