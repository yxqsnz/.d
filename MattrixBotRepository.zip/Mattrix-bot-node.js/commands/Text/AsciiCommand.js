const figlet = require("figlet");
const discord = require("discord.js");
module.exports = {
  name: "ascii",
  description: "transforma um texto pra ascii-art",
  usage: "<prefixo>ascii <texto>",
  aliases: ["textoparaascii", "texttoascii"],
  /**
   *
   * @param {discord.Client} client
   * @param {discord.Message} message
   * @param {String[]} args
   */
  run: async (client, message, args) => {
    if (!args.length) {
      await message.reply(
        "Desculpe mas está faltando um argumento obrigatório!"
      );
      return;
    }
    args = args.join(" ");
    if (args.length >= 40) {
      await message.reply("Desculpe o texto está muito grande.");
      return;
    }
    figlet(args, function (err, data) {
      if (err) {
        message.reply("Ocorreu um erro ao transformar o texto em ascii");
        return;
      }
      message.channel.send(`\`\`\`${data}\`\`\``);
    });
  },
};
