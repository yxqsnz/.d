const config = require("../Controllers/ConfigController");
const emoji = require('./Utils/Bot_Emojis')
const {MessageEmbed} = require('discord.js');
async function configureGuild(client,guild,prefix,customChannel){
    let found = 0;
    for (let channel of guild.channels.cache.array()){
      if (found === 0) {
        if (channel.type === "text") {
          if (channel.permissionsFor(client.user).has("VIEW_CHANNEL") === true) {
            if (channel.permissionsFor(client.user).has("SEND_MESSAGES") === true) {
              if(customChannel){
                channel = customChannel
              }
            
              if(found === 0){
                const m = channel.send(new MessageEmbed().setTitle(`${emoji.get_emoji(client,'discord_loading')} -> Configuring your guild...`).setColor("BLUE"));
                await config.NewSettings(guild.id);
                (await m).edit(new MessageEmbed().setTitle(`Thanks for adding me,My Default prefix is \`th!\`.`).setColor("GREEN"));
                found = 1;
                channel = undefined;
              }else{
                return;
              }
              found = 1;
              return;
              
            }
          
          }
      
        }
      

      }

    }
    


}
module.exports = {
  configureGuild,
}