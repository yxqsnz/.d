const fb = require('firebase')
const database = fb.default.database()

database.ref('economia/servidor/{guildid}/{user.id}') //abri uma area especifica do database.
.once('value').then(async function(db){  //inicia conexão com a area especifica do db
    if(db.val() == null){ //checa se o valor está null, ou seja, nunca foi alterado
        database.ref('economia/servidor/{guildid}/{user.id}')
        .set({
            variavel: 0,
            var: "variavel"
            //aqui setamos o valor de {variavel} para 0 e o valor de {var} para "variavel" 

        })
    } 
    
    //Pegando Valores
    console.log(db.val().variavel) // coloque a variavel que deseja pegar o valor
    
})

