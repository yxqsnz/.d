const firebase = require("firebase").default
const database = firebase.database()
