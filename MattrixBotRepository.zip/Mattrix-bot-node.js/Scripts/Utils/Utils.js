const { APIMessage, Structures } = require("discord.js");
const AntiSpam = require('discord-anti-spam');
const antiSpam = new AntiSpam({
  warnThreshold: 3, // Amount of messages sent in a row that will cause a warning.
  muteThreshold: 4, // Amount of messages sent in a row that will cause a mute
  kickThreshold: 7, // Amount of messages sent in a row that will cause a kick.
  banThreshold: 7, // Amount of messages sent in a row that will cause a ban.
  maxInterval: 2000, // Amount of time (in milliseconds) in which messages are considered spam.
  warnMessage: '{@user}, Please stop spamming.', // Message that will be sent in chat upon warning a user.
  kickMessage: '**{user_tag}** has been kicked for spamming.', // Message that will be sent in chat upon kicking a user.
  muteMessage: '**{user_tag}** has been muted for spamming.',// Message that will be sent in chat upon muting a user.
  banMessage: '**{user_tag}** has been banned for spamming.', // Message that will be sent in chat upon banning a user.
  maxDuplicatesWarning: 7, // Amount of duplicate messages that trigger a warning.
  maxDuplicatesKick: 10, // Amount of duplicate messages that trigger a warning.
  maxDuplicatesBan: 12, // Amount of duplicate messages that trigger a warning.
  exemptPermissions: [ 'ADMINISTRATOR'], // Bypass users with any of these permissions.
  ignoreBots: true, // Ignore bot messages.
  verbose: true, // Extended Logs from module.
  ignoredUsers: [], // Array of User IDs that get ignored.
  muteRoleName: "Muted", // Name of the role that will be given to muted users!
  removeMessages: true // If the bot should remove all the spam messages when taking action on a user!
  // And many more options... See the documentation.
});
class Message extends Structures.get("Message") {
  async inlineReply(content, options) {
    const mentionRepliedUser =
      typeof ((options || content || {}).allowedMentions || {}).repliedUser ===
      "undefined"
        ? true
        : (options || content).allowedMentions.repliedUser;
    delete ((options || content || {}).allowedMentions || {}).repliedUser;

    const apiMessage =
      content instanceof APIMessage
        ? content.resolveData()
        : APIMessage.create(this.channel, content, options).resolveData();
    Object.assign(apiMessage.data, {
      message_reference: { message_id: this.id },
    });

    if (
      !apiMessage.data.allowed_mentions ||
      Object.keys(apiMessage.data.allowed_mentions).length === 0
    )
      apiMessage.data.allowed_mentions = {
        parse: ["users", "roles", "everyone"],
      };
    if (typeof apiMessage.data.allowed_mentions.replied_user === "undefined")
      Object.assign(apiMessage.data.allowed_mentions, {
        replied_user: mentionRepliedUser,
      });

    if (Array.isArray(apiMessage.data.content)) {
      return Promise.all(
        apiMessage
          .split()
          .map((x) => {
            x.data.allowed_mentions = apiMessage.data.allowed_mentions;
            return x;
          })
          .map(this.inlineReply.bind(this))
      );
    }

    const { data, files } = await apiMessage.resolveFiles();
    return this.client.api.channels[this.channel.id].messages
      .post({ data, files })
      .then((d) => this.client.actions.MessageCreate.handle(d).message);
  }
}
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

Structures.extend("Message", () => Message);
module.exports = {
  Message,
  sleep,
  antiSpam,
};
