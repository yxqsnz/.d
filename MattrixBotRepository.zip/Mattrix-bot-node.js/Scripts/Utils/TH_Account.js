const DataBase = require("./database");
async function getDB(){
    return await DataBase.Client.db("Economy").collection("Users");
}
async function getUserBackground(userID){
    const db = await getDB();
    const {background:bg}= await db.findOne({user_id: userID});
    
    if (!bg){
        return 'https://cdn.discordapp.com/attachments/798545214532878379/818162312829599784/default.png'
    }
    else {
        switch(bg){
            case '1':
                return 'https://cdn.discordapp.com/attachments/798545214532878379/818162313601089537/1.png'
            case '2':
                return 'https://cdn.discordapp.com/attachments/798545214532878379/818162314661593108/2.jpg'
            case '3':
                return 'https://cdn.discordapp.com/attachments/798545214532878379/818162316800557066/3.jpg'
            default:
                return  'https://cdn.discordapp.com/attachments/798545214532878379/818162312829599784/default.png'
        }
    }
}
module.exports = {
    getUserBackground,

}