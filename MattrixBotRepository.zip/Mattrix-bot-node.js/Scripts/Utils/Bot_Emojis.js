const loading2 = (client) => {
  return client.emojis.cache.find((emoji) => emoji.name === "bot_loading2");
};
const ok = (client) => {
  return client.emojis.cache.find((emoji) => emoji.name === "bot_ok");
};
const error = (client) => {
  return client.emojis.cache.find((emoji) => emoji.name === "bot_error");
};
const loading = (client) => {
  return client.emojis.cache.find((emoji) => emoji.name === "bot_loading");
};
const loading3 = (client) => {
  return client.emojis.cache.find((emoji) => emoji.name === "bot_loading3");
};
const e_loading = (client, l) => {
  return client.emojis.cache.find(
    (emoji) => emoji.name === "bot_loading" + l.toString()
  );
};
const get_emoji = (client, emoji_name) => {
  return client.emojis.cache.find((emoji) => emoji.name === emoji_name);
};
module.exports = {
  get_emoji,
  e_loading,
  loading,
  loading2,
  loading3,
  ok,
  error,
};
