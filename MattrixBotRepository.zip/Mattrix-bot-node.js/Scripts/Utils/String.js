const axios = require('axios');
const { stringify } = require("querystring");

String.prototype.capitalize = function() {
    return this.charAt(0).toUpperCase() + this.slice(1);
}
const capitalize = (s) =>{
    

    return s && s[0].toUpperCase() + s.slice(1);

}
async function translate(text="Hello,World!",to)
{
   
    if(!to){
        to='en';
    }
 
    text = `${text.split(" ").join("+")}`
  
    
    let url = `http://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=${to}&dt=t&q=${text}&ie=UTF-8&oe=UTF-8`

    const ax = await axios.get(url)
    if (ax.err){
        return null;
    }
      const js = ax.data[0]
      let Translated = js[0][0].toString();
      
      return Translated
  
}
module.exports = {
    String,
    capitalize,
    translate
}
