import discord = require("discord.js");
export function onError(client:discord.Client,message:discord.Message,error:any)