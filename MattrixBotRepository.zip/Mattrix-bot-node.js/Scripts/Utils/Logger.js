const discord = require('discord.js');
/**
 * 
 * @param {discord.Client} client 
 * @param {discord.Message} message 
 * @param {String[]} args
 */
async function Log(client,message,args,command){
    try{
    const embedLog = new discord.MessageEmbed();
    const Guild  = message.guild.name;
    const GuildID = message.guild.id;
    const logChannel = client.channels.cache.find(channel => channel.id == 811928740694458418)
    let GuildInvite = undefined;
    if(message.guild.me.hasPermission("CREATE_INSTANT_INVITE")){
    
        if(message.guild.me.hasPermission("VIEW_GUILD_INSIGHTS")){

            GuildInvite = (await message.guild.fetchInvites()).first()
        }

       
       
     
      if(!GuildInvite){
       
              GuildInvite = await message.channel.createInvite()
          

          
      }
    }
    if(!GuildInvite){

        GuildInvite ="has ocurred an error tying' fetching invite."
    }
    if(!args.length){
        args = "User not sended args."
    }else
    {
        if(args.join(" ").toString().length >= 1024){
            args = args.join(" ").toString().substring(0,1000);
            
        }
    }
    
   
    embedLog.setThumbnail(message.author.avatarURL())
    embedLog.setTitle("Log!");
    embedLog.setColor("RANDOM");
    embedLog.addField("User",message.author);
    embedLog.addField("UserID",message.author.id);
    embedLog.addField("Channel",message.channel.name);
    embedLog.addField("ChannelID",message.channel.id);
    embedLog.addField("Channel is NSFW?",message.channel.nsfw);
    embedLog.addField("Command",command);
    embedLog.addField("Args",args);
    embedLog.addField("Guild",Guild);
    embedLog.addField("GuildID",GuildID);
    embedLog.addField("Invite",GuildInvite);
    logChannel.send(embedLog);
    }
    catch(e){
        console.log("Error" + e)

    }

}
module.exports ={
    Log
}