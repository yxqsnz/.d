async function FindEmojiByName(client, name: String) {
  let emojiSTR = "";
  const eid = client.emojis.cache.find((emoji) => emoji.name === name);
  if (eid.animated) {
    emojiSTR = `<a:${eid.name}:${eid}>`;
  } else {
    emojiSTR = `<:${eid.name}:${eid}>`;
  }
  return emojiSTR;
}
async function FindEmojiById(client, id: String) {
  let emojiSTR = "";
  const eid = await client.emojis.cache.get(id);
  const ename = await client.emojis.cache.get(id).name;
  if (eid.animated) {
    emojiSTR = `<a:${ename}:${eid}>`;
  } else {
    emojiSTR = `<:${ename}:${eid}>`;
  }
  return emojiSTR;
}
const ok = async (client) => {
  return await FindEmojiByName(client, 'bot_ok')
}
const error = async (client) => {
  return await FindEmojiByName(client, 'bot_error')
}
const loading = async (client) => {
  return await FindEmojiByName(client, 'bot_loading')
}
export { FindEmojiById, FindEmojiByName, ok, error, loading };
