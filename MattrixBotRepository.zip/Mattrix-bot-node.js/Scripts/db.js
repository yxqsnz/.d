const { MongoError, MongoClient } = require("mongodb");
const { MongoPath } = require("../config.js");
const Client = new MongoClient(MongoPath, {
  useUnifiedTopology: true,
  useNewUrlParser: true,
});
async function connectDB() {
  try {
    await Client.connect();
    console.log("[BOT/MONGODB]".white + " ✅|Connected to Database!".green);
  } catch (e) {
    console.log("[BOT/MONGODB]".white + ` ❌| Error: ${e}`.red);
  }
  if (Client.isConnected()) {
    return Client;
  }
}
module.exports = {
  connectDB,
  Client,
};
