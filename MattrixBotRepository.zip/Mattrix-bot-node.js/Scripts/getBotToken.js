const fs = require("fs");
const axios = require("axios");
require("colors");

async function Gettoken() {
  console.log("[TOKEN]".bold + " Decrypting Bot Token...".green);
  const c = await fs.readFileSync("./assets/BOT.TOKEN", "utf8", (e, d) => {
    return d;
  });
  const rep1 = await axios
    .post("https://cyppwall.herokuapp.com/decrypt", {
      content: c,
    })
    .then(function (response) {
      return response.data;
    })
    .catch(function (error) {
      console.log(error);
    });
  console.log("[TOKEN]".bold + " Token has been decrypted.".green);
  return rep1.text;
}
module.exports = {
  Gettoken,
};
