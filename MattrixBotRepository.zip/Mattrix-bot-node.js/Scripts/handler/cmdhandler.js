const { readdirSync } = require("fs");
const Timer = require("time-counter");
const ascii = require("ascii-table");
require("colors");
let table = new ascii("Commands");
table.setHeading("Command", " Load status", "Language");
let CommandLoadedWithSuccess = 0;
let CommandLoadedWithErrors = 0;
let JavaScriptCommands = 0;
let TypeScriptCommands = 0;
module.exports = (client) => {
  const TimeToLoadCommands = new Timer();
  TimeToLoadCommands.start();
  readdirSync("./commands/").forEach((dir) => {
    const commands = readdirSync(`./commands/${dir}/`).filter(
      (file) => file.endsWith(".js") || file.endsWith(".ts")
    );
    for (let file of commands) {
      console.log(file);
      let pull = require(`../../commands/${dir}/${file}`);
      let Language = "";
      if (file.endsWith(".js")) {
        Language = "JavaScript";
        JavaScriptCommands++;
      } else if (file.endsWith(".ts")) {
        Language = "TypeScript";
        TypeScriptCommands++;
      } else {
        Language = null;
      }
      if (pull.name) {
        client.commands.set(pull.name, pull);
        table.addRow(pull.name, "✅ -> Command Loaded!", Language);
        CommandLoadedWithSuccess++;
      } else {
        table.addRow(
          file,
          "❌ -> Missing a help.name, or help.name is not a string.",
          "404"
        );
        CommandLoadedWithErrors++;
        continue;
      }
      if(pull.minBotPermissions){
        client.minBotPermCommands.set(pull.name,pull.minBotPermissions)
      }
      if(pull.minPermissions){
        client.minPermCommands.set(pull.name,pull.minPermissions)
      }
      if (pull.aliases && Array.isArray(pull.aliases))
        pull.aliases.forEach((alias) => client.aliases.set(alias, pull.name));
    }
  });
  TimeToLoadCommands.stop();
  const TimeToLoadCommandsI =
    TimeToLoadCommands.stoppedTime - TimeToLoadCommands.timerStartTime;

  console.log(table.toString());
  console.log(client.minBotPermCommands);
  console.log(
    "[BOT/COMMAND HANDLER] ".blue +
      "Loaded " +
      CommandLoadedWithSuccess.toString().bold +
      " Commands in " +
      TimeToLoadCommandsI.toString().bold +
      " ms has occurred " +
      CommandLoadedWithErrors.toString().bold +
      " Errors.\nCommands in JS: " +
      JavaScriptCommands.toString().bold +
      " Commands in TS: " +
      TypeScriptCommands.toString().bold +
      "."
  );
};
