
async function Run(subCommand,client,message,args){  
    let subCommandArgs = []
    const subCommandObject = client.subCommands.get(subCommand);
    
    subCommandArgs = args;
    subCommandArgs.shift()
    subCommandObject.run(client,message,subCommandArgs);
}
module.exports = {
    Run,
}