const { readdirSync } = require("fs");
module.exports = (client) => {
  readdirSync("./subCommands/").forEach((dir) => {
    const commands = readdirSync(`./subCommands/${dir}/`).filter(
      (file) => file.endsWith(".js") || file.endsWith(".ts")
    );
    for (let file of commands) {
      console.log(file);
      let pull = require(`../../subCommands/${dir}/${file}`);
      
      if (pull.name) {
        client.subCommands.set(pull.name, pull);
        console.log(`Loaded subCommand ${pull.name} of command ${pull.command}`);
      } else {
        
        continue;
      }
    }
  });

};
