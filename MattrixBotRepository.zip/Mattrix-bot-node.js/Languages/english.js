module.exports = {
    LanguageSwitchSuccess:"Now i'm speaking in english",
    MemberPunished: (memberName,punishment) => `Member Punished || Member: ${memberName} has been ${punishment}.`,
    BanConfirmation:(username,reason) => `Do you really want to ban ${username}?\nReason: ${reason}`
}