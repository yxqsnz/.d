console.log("You're Using Canary version of Thobias bot.");
const DbCore = require('./Scripts/db');

const Config = require('./Controllers/ConfigController');
const db = require("./Scripts/Utils/database")
const {getGuildLocale,load,ReloadLocales} = require('./Controllers/LanguageController');
const { Client, MessageEmbed, Collection, Guild } = require("discord.js");
const { readdirSync } = require("fs");
const json = require('./Controllers/jsonController');
const { Log } = require("./Scripts/Utils/Logger");

const config = require("./config.js");
const l = require("./Scripts/handler/cmdhandler.js");
const dp = require("discord-prefix");
const fb = require("firebase");
const emoji = require("./Scripts/Utils/Bot_Emojis.js");
const multiLanguage = require('./Controllers/LanguageController')

const talkedRecently = new Set();
/**
 * @param {Client} client
 */
async function ThobiasBot(){

  await ReloadLocales();
  const client = new Client({ disableEveryone: true });
  const colors = require("colors");
  client.commands = new Collection();
  client.aliases = new Collection();
  client.subCommands = new Collection();
  client.minBotPermCommands = new Collection();
  client.minPermCommands = new Collection();

 
  let defaultPrefix = config.dprefix;
  require("./Scripts/Utils/Utils.js");
  //sa porra de exports é uma merda
  //vou ligar a db aqui
  
 
  //tutorial de firebase em ./Scripts/fb-tutorial/
 
  require("./Events/LoadEvents")(client);

  client.categories = readdirSync("./commands/");
  ["command"].forEach((handler) => {
    l(client);
  });
  require('./Scripts/handler/subcmdhandler')(client);
  fb.default.initializeApp(FirebaseConfig);
  console.log("[BOT]".green + " Inciando bot...".gray);
  //conectado
  console.log("[BOT/FB]".yellow + " Firebase iniciado".gray);

  /**
   * 
   * @param {Guild} guild 
   */
  client.on("guildCreate",async (guild) =>{

    if(db.Client.isConnected){
      const {configureGuild} = require('./Scripts/Guild');
      await configureGuild(client,guild,defaultPrefix);
  
  }
  })
  client.on("message", async (message) => {
    if(!message.guild){
      return;
    }
    let prefix = ""
    if(message.guild){
      
        prefix =  Config.LoadSettings(message.guild.id).prefix;
    
    }
  
    if (!prefix) prefix = defaultPrefix;
    if (!message.guild) {
      let prefix = "!";
    }
    if (message.mentions.has(client.user) && !message.mentions.everyone) {
      const embed = new MessageEmbed();
      embed.setTitle(getGuildLocale(message.guild.id,"OnMention",prefix));
      embed.setColor(message.member.displayHexColor);
      message.reply(embed);
    }
    if (message.author.bot) return;
  
    if (!message.content.startsWith(prefix)) return;
    if (!message.guild) return;
    if (!message.member)
      message.member = await message.guild.fetchMember(message);
    const args = message.content.slice(prefix.length).trim().split(/ +/g);
    const cmd = args.shift().toLowerCase();
    if (cmd.length == 0) return;
    let command = client.commands.get(cmd);
    if (!command) command = client.commands.get(client.aliases.get(cmd));
    function runcmd(client, message, args) {
      message.channel.send("WARNING: You're using Canary version.\nDon't report bugs of this version.").then(m =>{
        m.delete({timeout:2000}).catch()
      })
      let InvalidPermissions = [];
      let ValidPermissions = "";
      if(client.minBotPermCommands.get(command.name)){
        for(const perm of client.minPermCommands.get(command.name)){
          if(!message.guild.me.hasPermission(perm)){
            InvalidPermissions.push(perm)
          }
        }
        if(InvalidPermissions.length >= 1){
          const MissingPermissionEmbed = new MessageEmbed();
          MissingPermissionEmbed.setTitle(getGuildLocale(message.guild.id,"BotMissingPermission"));
          MissingPermissionEmbed.setDescription(getGuildLocale(message.guild.id,"BotMissingPermissionMessage",InvalidPermissions.join(",")));
          MissingPermissionEmbed.setColor("RED");
  
          message.inlineReply(MissingPermissionEmbed)
          return;
        }
      }
      if(client.minPermCommands.get(command.name)){
        for(const perm of client.minPermCommands.get(command.name)){
         
          if(perm == "DEV"){
            for(const dev of config.dev){
              if(!message.author.id == dev){
                InvalidPermissions .push("bot developer")
                break;
              }
              break;
            }
          }else{
            if(message.member.hasPermission(perm)){
              ValidPermissions += `${perm} `;
              
            }
            else
            {
              InvalidPermissions += `${perm} `
              
            }
          }
         
        }
        if(InvalidPermissions.length >= 1){
          const MissingPermissionEmbed = new MessageEmbed();
          MissingPermissionEmbed.setTitle(getGuildLocale(message.guild.id,"UserMissingPermission"));
          MissingPermissionEmbed.setTimestamp();
          MissingPermissionEmbed.setColor("RED");
          try{
          MissingPermissionEmbed.setDescription(getGuildLocale(message.guild.id,"UserMissingPermissionMessage",InvalidPermissions.join(",").toString()));
          message.inlineReply(MissingPermissionEmbed);
          }catch(e){}
          return;
        }
       
      }
  
      command.run(client, message, args, multiLanguage).catch((e) =>{
        //.split("||")[0]
        const localse =  getGuildLocale(message.guild.id,"CommandErrorEmbed")
              try{
          const errorEmbed = new MessageEmbed();
          errorEmbed.setTitle(localse.split("||")[0]);
          errorEmbed.setDescription(localse.split("||")[1]);
          let error = "```js\n" + e.toString() 
          if(error.length >= 1024){
            error.substring(0,1000);
            error += "..."
          } 
          error += "```"
          errorEmbed.setColor("RED");
          errorEmbed.setFooter(message.author.username,message.author.avatarURL());
          errorEmbed.setTimestamp();
          errorEmbed.setThumbnail("https://media1.tenor.com/images/41334cbe64331dad2e2dc6272334b47f/tenor.gif");
          errorEmbed.addField("ERR!",error,true);
          message.inlineReply(errorEmbed)
        }
        catch(e){
          console.error(e);
        }
      });
      Log(client, message, args, cmd);
      
      
        
  
    }
  
    if (command) {
      if (talkedRecently.has(message.author.id)) {
        const ErrorEmbed = new MessageEmbed();
        ErrorEmbed.setTitle(getGuildLocale(message.guild.id,"CommandCoolDown",emoji.error(client),5));
        ErrorEmbed.setColor(message.member.displayHexColor);
        message.inlineReply(ErrorEmbed);
      } else {
        runcmd(client, message, args)
        
        talkedRecently.add(message.author.id);
        setTimeout(() => {
          talkedRecently.delete(message.author.id);
        }, 5000);
      }
    } else {
      
      if(Config.LoadSettings(message.guild.id).commandNotFoundMessageEnabled == "on"){
        await message.inlineReply(getGuildLocale(message.guild.id,"CommandNotFound"));
      }

     
      }
  
  });
  client.on("ready", async () => {
    await Config.SyncSettings(client);
    await load(client);
  
  });

}
async function init() {
  await db.Client
  await db.db
  ThobiasBot();
  

}
try {
  init();
} catch (e) {
  console.log("err :(" + e);
}
