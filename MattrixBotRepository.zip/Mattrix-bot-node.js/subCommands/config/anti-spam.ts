import discord = require('discord.js');
import json = require('../../Controllers/jsonController')
import File = require('fs');
module.exports = {
    "command":"config",
    "name":"anti-spam",
    run: async (client:discord.Client,message:discord.Message,args:String[]) =>{
        
    }
}