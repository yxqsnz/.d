import controller = require("../../Controllers/ConfigController");
import Discord = require('discord.js');
import text = require('../../Controllers/LanguageController')
module.exports = {
    name:"commandNotFound",
    command:"config",
    run: async (client:Discord.Client,message:Discord.Message,args:String[]) =>{
        const config = await controller.LoadSettings(message.guild.id);
        if(!args.length){
            message.reply(text.getGuildLocale(message.guild.id,"CommandNotFoundMessageIs",config.commandNotFoundMessageEnabled));
            return;
        }
        let option = args[0].toLowerCase();      
        if(!option){ 
           return message.reply(text.getGuildLocale(message.guild.id,"MissingRequiredArgument","ON/OFF"))
        }
        if(option == "on" || option == "off"){}else{option = 'false'};
       
      
         if(config.commandNotFoundMessageEnabled == option && config.commandNotFoundMessageEnabled == "on"){
            return message.reply(text.getGuildLocale(message.guild.id,"CommandNotFoundAlreadyEnabled"))
         }else if (config.commandNotFoundMessageEnabled == option && config.commandNotFoundMessageEnabled == "off") {
            return message.reply(text.getGuildLocale(message.guild.id,"CommandNotFoundAlreadyDisabled"))
         }
        config.commandNotFoundMessageEnabled = option;
        if(option == "on")
        { 
            controller.SetCMDNotFound(message.guild.id,"on")
            await message.reply(text.getGuildLocale(message.guild.id,"CommandNotFoundEnabled"));
        }else{
            controller.SetCMDNotFound(message.guild.id,"off")
            await message.reply(text.getGuildLocale(message.guild.id,"CommandNotFoundDisabled"));
        }
      
    }
}