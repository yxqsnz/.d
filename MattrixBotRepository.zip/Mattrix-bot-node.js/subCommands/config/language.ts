import discord = require('discord.js');
import models = require('../../Models/Configuration')
import l = require("../../Controllers/LanguageController")
import controller = require("../../Controllers/LanguageController")
import database = require("../../Scripts/Utils/database");
const lfiles = require('../../Languages/Languages.json');
module.exports = {
    "command":"config",
    "name":"language",
    run: async (client:discord.Client,message:discord.Message,args) =>{
        const GuildDb = database.Client.db("Guild");
        const config = GuildDb.collection("Config");
        
        if(!args.length){
            message.reply(await l.getGuildLocale(message.guild.id,"MissingRequiredArgument","Language"));
            return;
        }
        const language = args[0];
        if(!lfiles.supported_languages.includes(language.toLowerCase())){
            message.reply("I don't support this language.");
            return;
        }

           await config.updateOne(
            {
              guildID : message.guild.id
            },
            {
              $set: { language:language },
            }
          );

        await controller.set(message.guild,language)
        message.reply(controller.getGuildLocale(message.guild.id,"LanguageSwitchSuccess")).then((message) =>{
            message.delete({timeout:5000})
        })
    }
}