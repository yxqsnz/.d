const Discord = require('discord.js');
const Locale = require('../../Controllers/LanguageController');
const Database = require('../../Scripts/Utils/database');
module.exports = {
    "command":"background",
    "name":"buy",
    /**
     * 
     * @param {Discord.Client} client 
     * @param {Discord.Message} message 
     * @param {String[]} args 
     */
    run: async (client,message,args) => {
            const ValidBackGrounds = [1,2,3] 
            const EconomyDB = await Database.Client.db("Economy")
            const Economy = await EconomyDB.collection("Users")
            const BackGrounds =  await EconomyDB.collection("Backgrounds")
    
            const User = await Economy.findOne({user_id: message.author.id});
            if(!args.length){
                return message.reply(Locale.getGuildLocale(message.guild.id,"PleaseSelectABackground"))
            }
            const SelectedBackGround = parseInt( args[0]);  
            if(!ValidBackGrounds.includes(SelectedBackGround)) return message.reply(message.guild.id,"InvalidBackground")
      
            switch (SelectedBackGround){
                case 1:
                    BuyBackGround(SelectedBackGround)
                    break;
                case 2:
                    BuyBackGround(SelectedBackGround)
                case 3:
                    BuyBackGround(SelectedBackGround)
                    break;

            }
        async function BuyBackGround(backID){
            console.log(await BackGrounds.find().toArray())
            const s = {
                BackID: `${backID}`
            }
            const bg = await BackGrounds.findOne(s);
            const uMoney = User['money'];
            
            if(bg['price'] > uMoney){
                return message.reply(Locale.getGuildLocale(message.guild.id,"BackGroundNoSufficientMM",bg['price']))
            }
            if(User['BackGrounds']){
                
                if(User['BackGrounds'].includes(`${bg['BackID']}`)){ 
                    return await message.reply(Locale.getGuildLocale(message.guild.id,"BackGroundYouAlreadyContainsBack"));
                }
            }
            const Confirmation = new Discord.MessageEmbed();
            Confirmation.setTitle("BackGround");
            Confirmation.setColor(message.member.displayHexColor);
            Confirmation.setDescription(Locale.getGuildLocale(message.guild.id,"BackGroundBuyConfirmation",bg['price'],bg['name'],bg['BackID']))
            const m = await message.channel.send(Confirmation);
            (await m).react("✅");
            const filter = (reaction, user) => {
                return reaction.emoji.name === '✅' && user.id === message.author.id;
            };
            let buy = false; 
            const collector = (await m).createReactionCollector(filter,{time:40000});
            collector.on("collect", async () =>{
                buy = true;
                Economy.updateOne({
                    user_id:message.author.id
                },
                {
                   $set: {money: User['money'] - bg['price'], background: bg['BackID']}
                })
                Economy.updateOne({
                    user_id:message.author.id
                },
                {
                   $push: {BackGrounds: bg['BackID']}
                })
                
                await m.delete().catch();
                message.reply(Locale.getGuildLocale(message.guild.id,"BackGroundBuySuccess",bg['name']))
            })
            collector.on('end', async () =>{
                 if(!buy){
                    await m.delete().catch()
                 }
            })
        }
    }
}