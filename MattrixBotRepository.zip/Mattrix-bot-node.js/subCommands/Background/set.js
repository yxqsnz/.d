const Discord = require('discord.js');
const Locale = require('../../Controllers/LanguageController');
const Database = require('../../Scripts/Utils/database');
module.exports = {
    "command":"background",
    "name":"set",
    /**
     * 
     * @param {Discord.Client} client 
     * @param {Discord.Message} message 
     * @param {String[]} args 
     */
    run: async (client,message,args) => {
            const ValidBackGrounds = ['1','2','3'] 
            const Economy = await Database.Client.db("Economy").collection("Users");
            const User = await Economy.findOne({user_id: message.author.id});
            if(!User['BackGrounds']){
                return message.reply(Locale.getGuildLocale(message.guild.id,"YouDontHaveBackgrounds"));
            }
            const SelectedBackGround = args[0];  
            console.log(SelectedBackGround); 
            if(!ValidBackGrounds.includes(SelectedBackGround)){
               return message.reply(Locale.getGuildLocale(message.guild.id,"BackGroundNotFound"))
            }
            if(!User.BackGrounds.includes(SelectedBackGround)){
               return  message.reply(Locale.getGuildLocale(message.guild.id,'YouDontHaveBackground'))
            }
            const bg = await Database.Client.db("Economy").collection("Backgrounds").findOne({BackID: SelectedBackGround})
            Economy.updateOne({
                user_id:message.author.id
            },
            {
               $set: {background: bg['BackID']}
            })
            message.reply(Locale.getGuildLocale(message.guild.id,"BackGroundSwitchSuccess",bg['name']))
}
}