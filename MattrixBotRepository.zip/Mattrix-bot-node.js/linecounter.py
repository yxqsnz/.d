import os,sys

lines =0;
pythonFiles = 0;
jsFiles = 0;
tsFiles = 0;
goFiles = 0;
pythonLength = 0;
jsLength = 0;
tsLength = 0;
goLength = 0;
totalLength = 0;
totalFiles = 0;
csFiles = 0;
csLength = 0;
jsonFiles = 0;
jsonLength = 0;
LOGS = open('logs.log','a');
from tabulate import tabulate
print(f"On project {os.path.dirname(__file__)}")
LOGS.write(f"[PROJECT] [INFO] - On project {os.path.dirname(__file__)}\n")
for root,sub,f in os.walk("./"):
   if(root.__contains__("./node_modules" )):
       pass
   elif (root.__contains__("./.git")):
       pass
   elif (root.__contains__("package.json")):
       pass
   else:
       for file in os.listdir(root):
           if(file == os.path.basename(__file__)):
               continue;
           LOGS.write(f"[FILES] [INFO] - Reading [PATH] -> \"{root}\" <- [PATH] [FILE] -> \"{file}\" <- [FILE] ...\n")
           f = f"{root}/{file}";
           if(f.endswith(".go")):
               goFiles += 1;
               
               print(f'reading ${f}');
            
               fl = open(f,'r', encoding="utf8");
               for line in fl:
    
                   goLength += 1;
           elif (f.endswith(".js")):
               jsFiles += 1;
               print(f'reading ${f}');
               fl = open(f,'r', encoding="utf8");
               for line in fl:
                jsLength += 1;
           elif (f.endswith(".ts")):
               tsFiles += 1;
               print(f'reading ${f}');
               fl = open(f,'r', encoding="utf8");
               for line in fl:
                tsLength += 1;
           elif (f.endswith(".py")):
               pythonFiles += 1;
               print(f'reading ${f}');
               fl = open(f,'r', encoding="utf8");
               for line in fl:
                pythonLength += 1;
           elif (f.endswith(".cs")):
               csFiles += 1;
               print(f'reading ${f}');
               fl = open(f,'r', encoding="utf8");
               for line in fl:
                csLength += 1;
           elif (f.endswith(".json")):
               jsonFiles += 1;
               print(f'reading ${f}');
               fl = open(f,'r', encoding="utf8");
               for line in fl:
                jsonLength += 1;      
totalLength = pythonLength + jsLength + tsLength + goLength + csLength + jsonLength;
totalFiles = pythonFiles + jsFiles + tsFiles + goFiles + csFiles + jsonFiles;
print("\nREADY\n")
data = [["Language","Files","Lines"],
["JavaScript",jsFiles,jsLength],
["Typescript",tsFiles,tsLength],
["Go",goFiles,goLength],
["Python",pythonFiles,pythonLength],
["C#",csFiles,csLength],
["JSON",jsonFiles,jsonLength],
["TOTAL",totalFiles,totalLength]]
table =  tabulate(data, headers='firstrow')
print(table)
print("Press enter to exit.");
input();

