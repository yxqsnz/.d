const Discord = require('discord.js');
const DataBase = require('../../Scripts/Utils/database');
/**
 * @param {Discord.Client} client
 */
module.exports = async client =>{
    client.on('ready', () =>{
        async function checkMutes(){
            const db = await DataBase.Client.db("Guild").collection("Mutes")
            const Mutes = await db.find();
            const obj = {
                current:"YES"
            }

          
            const mutesWithObj = await db.find(obj);

           
            const x = Date.now();
            const ms = await mutesWithObj.toArray()
            if(ms.length){
                for (const mute of ms){
                    if(mute['expires'] && mute['current'] == "YES"){
                        if(x >= mute['expires'].getTime()){
                        console.log(mute);
                        const guild = client.guilds.cache.find(g => g.id == mute['guildID'])
                        if(guild)
                        { 
                            const role = await guild.roles.cache.find(r => r.name === "TH_MUTED");
                            if (role)
                              { 
                                  const member = (await guild.members.fetch()).find(m => m.id == mute['memberID'])
                                  if (member){
                                    if(guild.me.hasPermission("MANAGE_ROLES"))
                                    {
                                     await  member.roles.remove(role).catch();
                                     db.updateMany({
                                        expires: mute['expires'],
                                        current: 'YES'
                                     },{
                                        $set:{current: "NO"}
                                     })
                           }}}}}}}}
            setTimeout(checkMutes,60 * 30 * 4)
        }
           checkMutes();
        client.on("guildMemberAdd" , async member => {
            const db = await DataBase.Client.db("Guild").collection("Mutes")
            
            const isMuted = await db.findOne({
                memberID: member.id,
                guildID: member.guild.id,
                current: "YES",
            })
            if(isMuted){
                const role = await member.guild.roles.cache.find(r => r.name === "TH_MUTED");
                if(role){
                    if(member.guild.me.hasPermission("MANAGE_ROLES")){
                        member.roles.add(role).catch();
                    }
                }
            }
        })
    })
}