import colors = require('colors')
import discord = require("discord.js")
import Time = require("../../Scripts/Utils/Utils")

module.exports = (client) => {
  
  client.on("ready", () =>{
    changeStatus(client)
    console.log("[BOT/FB]".yellow + " Firebase 100%".bold);
    console.log(colors.green(`[BOT] ✅ -  BOT ONLINE ${client.user.username}!`));
  })
    
}
 async function changeStatus(client:discord.Client)
 {

    while (true)
     {
          
         client.user.setPresence({status:"idle",activity:{type:"LISTENING",name:`Com ${client.users.cache.array().length} Membros!`}})

        await Time.sleep(10000);

         client.user.setPresence({activity:{name:"!help",type:"STREAMING",url:"https://twitch.tv/"}});
        await Time.sleep(10000);
      client.user.setActivity("Re:Zero Stating life in another world",{type:"WATCHING",url:"https://www.crunchyroll.com/rezero-starting-life-in-another-world-"});
        await Time.sleep(10000);
        client.user.setActivity("That Time i got Reincarnated as a Slime",{ type:"WATCHING", url:"https://www.crunchyroll.com/that-time-i-got-reincarnated-as-a-slime"});
        await Time.sleep(10000);
        client.user.setActivity("DemonSlayer: Kimetsu no Yaiba", {type:"WATCHING",url:"https://www.crunchyroll.com/demon-slayer-kimetsu-no-yaiba"})
        await Time.sleep(10000);
        
     }
    
 }