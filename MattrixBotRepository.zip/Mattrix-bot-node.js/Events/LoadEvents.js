  
const path = require('path')
const fs = require('fs')
require('colors')
module.exports = (client) => {
  const LoadEvents = (dir) => {
    const files = fs.readdirSync(path.join(__dirname, dir))
    for (const file of files) {
      const stat = fs.lstatSync(path.join(__dirname, dir, file))
      if (stat.isDirectory()) {
        LoadEvents(path.join(dir, file))
      } else if (file !== 'LoadEvents.js') {
        const event = require(path.join(__dirname, dir, file))
        console.log("[EVENT]".yellow + `Loaded Event "${file}"`)
        event(client)
      }
    }
  }

  LoadEvents('.')
}