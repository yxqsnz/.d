
const DataBase = require("../Scripts/Utils/database");
async function getMuteDB(){
    return await DataBase.Client.db("Guild").collection("Mutes");
}
async function New(staffID,guildID,memberID,muteTime){
    const OBJ = {
        staffID: staffID,
        guildID: guildID,
        memberID:memberID,
        expires: muteTime,
        current: "YES"
    }
    const db = await getMuteDB();
    try{
    console.log(db);
    await db.insertOne(OBJ);
    return true;
    }
    catch (e) {
        console.error(`[MUTE/NEW] An error has ocurred: ${e}`)
        return false
    }

}

async function UnMute(guildID,memberID){

}
async function getPreviousMutes(targetID){
    const db = await getMuteDB();
    const p  = await db.find({memberID: targetID});
    if(!p){
        return false
    }
    return p;
}
module.exports = {
    New,
    UnMute,
    getPreviousMutes
}