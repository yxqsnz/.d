const database = require("../Scripts/Utils/database");
const cfgM = require("../Models/Configuration");
require('colors');
const config = cfgM.GuildConfig
async function NewSettings(guildID)  {
	const guildDB = database.Client.db("Guild")
configCollection = guildDB.collection('Config');
	console.log("[CONFIG]".blue + "bot added to a guild...".gray)
	config.guildID = guildID
	try{await configCollection.insertOne(config);return true;}catch(e){
		console.error(e)
		return false;
	}
}
async function SetCMDNotFound(guildId,on){
	ConfigCache[guildId].commandNotFoundMessageEnabled = on;
	const Configuration = await database.Client.db("Guild").collection('Config');
    await Configuration.updateOne(
        {
          guildID: guild.id,
        },
        {
          $set:{ commandNotFoundMessageEnabled: on},
        }
      );
}
async function SaveSettings (guildID, config) {
	ConfigCache[guildID] = config;
	const Configuration = await database.Client.db("Guild").collection('Config');


}
const ConfigCache = {};
async function SyncSettings (client) {
	try {
		console.log("[CONFIG]".blue + " Synchronizing Settings to cache...".green);
        for (guild of client.guilds.cache.array()) {
            
            const guildID = guild.id;
			config.guildID = guildID;
            const Configuration = await database.Client.db("Guild").collection('Config');
            const guildConfiguration = await Configuration.findOne({ guildID: guildID });
            if(!guildConfiguration){ConfigCache[guildID] = config;}else{ConfigCache[guildID] = guildConfiguration;}
        }
		console.log("[CONFIG]".blue + " Ok - Sync Success.".green);
	
    } catch (e) {
        console.error("[CONFIG]".blue + `:( - ERR!: `.red)
        console.error(e);
    }
}
function LoadSettings (guildID) {	
	return ConfigCache[guildID];
}
module.exports = {
	SaveSettings,
	LoadSettings,
	NewSettings,
	SyncSettings,
	SetCMDNotFound
}
