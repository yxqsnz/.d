const fs = require('fs')
var path = require('path');
const io = require('./IOController');
async function downloadToCache(url,name){
    const PATH = `${path.dirname(require.main.filename)}/assets/cache/${name}`
    
    if(!fs.existsSync(PATH)){
        io.downloadFile(url,PATH);    
    }
    setTimeout(() => {
        try{
            io.deleteFile(PATH);
        }
        catch(e) {

        }
    }, 30000);
}
module.exports = {
    downloadToCache
}