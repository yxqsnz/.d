const fs = require('fs')
var path = require('path');
let ptLocale = "";
let enLocale = "";
const LanguagesJSON = require('../Languages/Languages.json') 
const database = require('../Scripts/Utils/database');
const Config = require('./ConfigController')
const locales = {};
function ReloadLocales() {
    
    let fenPath = path.dirname(require.main.filename) + LanguagesJSON.english;
    let fptPath = path.dirname(require.main.filename) + LanguagesJSON.portuguese;
    try{
        console.log("[LOCALE]".green + " Deleting Cache...")
        delete require.cache[require.resolve(fenPath)]
        delete require.cache[require.resolve(fptPath)]
    }
    catch(e){

    }
    console.log("[LOCALE]".green + " READING LOCALES...")
    ptLocale = require(fptPath);
    enLocale = require(fenPath);
    

}
const guildLanguagesCache = {};
async function load(client) {
    console.log("[LOCALE]".green + " Synchronizing Guilds to cache...".gray);
    try {
        for (guild of client.guilds.cache.array()) {
            
            const guildID = guild.id;
            const Configuration = await database.Client.db("Guild").collection('Config');
            const guildConfiguration = await Configuration.findOne({ guildID: guildID });
           
            if(!guildConfiguration){
                
                    guildLanguagesCache[guildID] = 'english' 
                
            }else{
            guildLanguagesCache[guildID] = guildConfiguration.language
           }
               
            
        }
    } catch (e) {
        console.error(`:( - An error has ocurred Loading guild languages: `)
        console.error(e);
    }
    console.log("[LOCALE]".green + " Ok - Sync Success".gray);
   

}
async function set(guild, language) {
    guildLanguagesCache[guild.id] = language.toLowerCase(); 
    const Configuration = await database.Client.db("Guild").collection('Config');
    Configuration.updateOne(
        {
          guildID: guild.id,
        },
        {
          $set: { language: language.toLowerCase() },
        }
      );

}


const getGuildLocale = (guildID,key,...args) =>{
    let locale = "";
    let language = guildLanguagesCache[guildID];
    if(!language) {
        language = "english"
    }
    switch (language) {
        case 'portuguese':
            locale = ptLocale;
            break;
        case 'english':
            locale = enLocale;
            break;
        default:
            locale = "Invalid Language!";
            break;
    }
    
    let translation = locale[key]; 
    console.log(translation(...args))
    if(!translation){
       translation = `key \`${key}\` is invalid!`
    }
    if(typeof translation === "function") return translation(...args);
    else return translation;
}
function getLocale(language, string, ...vars) {
    let locale = "";
    
    switch (language) {
        case 'portuguese':
            locale = ptLocale[string];
            break;
        case 'english':
            locale = enLocale[string];
            break;
        default:
            locale = "Invalid Language!";
            break;
    }

    let count = 0;
    if(!locale){
        locale = "Isso não foi traduzido ainda por favor troque de linguagem.\nThis has not been translated yet, please change the language."
        return locale;
    }

 
    console.log(vars)
    locale = locale.replace(/%VAR%/g, () => vars[count] !== null ? vars[count] : "%VAR%");
    return locale;
}


module.exports = {
    getLocale,
    getGuildLocale,
    ReloadLocales,
    load,
    set,
    getGuildLocale
}