const fs = require('fs');
function writeJson(path,content){
    content = JSON.stringify(content);
    fs.writeFile(path,content,'utf-8',() =>{});
}
    
function readJson(path){
  
    const content = JSON.parse(fs.readFileSync(path,'utf-8'));
    return content;
}
module.exports = {
    writeJson,
    readJson,
}