const axios = require('axios')
const fs = require('fs');
async function downloadFile(url,path){
    const r = await axios({
        url,
        method: 'GET',
        responseType: 'stream'
      })
    if(!r.status == 200){
        return false;
    }
    const stream = fs.createWriteStream(path);
    r.data.pipe(stream)
}
async function deleteFile(path){
    await fs.rmSync(path);
}
const BOTPATH = require('path').dirname(require.main.filename)
module.exports = {
    downloadFile,
    deleteFile,
    BOTPATH
}