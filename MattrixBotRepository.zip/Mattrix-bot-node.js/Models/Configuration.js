const GuildConfig  = {
	guildID:0000,
	language:'portuguese',
	commandNotFoundMessageEnabled:"off",
	antiSpamEnabled:"false",
	punishmentChannel:"",
    prefix:"!"
};
module.exports = {
    GuildConfig
}