# Eu sei o código dessa merda está ruim e feio pra KARALHO.
## Esse bot está bugado pra krl e não recomendo ninguém usar o código desse bot.
# se você realmente quiser consertar esse bot ja recomendo ir ao psiquiatra 2 vezes por **dia**. ao mexer nesse codigo você pode desenvolver mais de 300 doenças mentais (vai virar usuario de twitter). caso MESMO ASSIM você ainda queira mexer nisso eu te desejo boa sorte.
